# USDT شام

منصة تداول ند للند في سوريا: USDT مقابل الليرة السورية والدولار عبر شام كاش. موقع + بوت تلغرام.

## التشغيل

```bash
cd backend && npm install
cd ../frontend && npm install
```

```bash
node backend/server.js
```

```bash
npm run dev --prefix frontend
```

الحسابات التجريبية:

- demo / demo123
- merchant / merchant123
- buyer / buyer123
- admin / admin123

## بوت تلغرام

أنشئ بوتاً من BotFather ثم:

```bash
TELEGRAM_BOT_TOKEN=your_token node backend/bot.js
```
