#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d backend/node_modules ]; then
  (cd backend && npm install)
fi
if [ ! -d frontend/node_modules ]; then
  (cd frontend && npm install)
fi

node backend/server.js &
BACKEND_PID=$!

if [ -n "$TELEGRAM_BOT_TOKEN" ]; then
  node backend/bot.js &
  BOT_PID=$!
fi

cleanup() {
  kill "$BACKEND_PID" 2>/dev/null || true
  if [ -n "${BOT_PID:-}" ]; then
    kill "$BOT_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

cd frontend && npm run dev
