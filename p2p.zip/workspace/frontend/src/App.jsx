import React, { useEffect, useState } from "react";
import { NavLink, Route, Routes, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "./auth.jsx";
import { useMeta } from "./meta.jsx";
import { api, authedUrl, readFileAsDataUrl } from "./api.js";

const STATUS = {
  pending_payment: "بانتظار الدفع",
  paid: "مدفوعة",
  completed: "مكتملة",
  cancelled: "ملغاة",
  disputed: "نزاع",
  pending: "بانتظار موافقة المدير",
  rejected: "مرفوض",
  active: "نشط",
  paused: "متوقف",
  filled: "نفد"
};

function money(n, d = 2) {
  return Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: d });
}

function Toast({ text, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2800);
    return () => clearTimeout(t);
  }, [onDone]);
  if (!text) return null;
  return <div className="toast">{text}</div>;
}

function Topbar() {
  const { user, logout } = useAuth();
  return (
    <header className="topbar">
      <NavLink to="/" className="brand">
        <span className="logo">ش</span>
        USDT شام
      </NavLink>
      <nav className="nav">
        <NavLink to="/" end>
          السوق
        </NavLink>
        <NavLink to="/orders">صفقاتي</NavLink>
        <NavLink to="/wallet">المحفظة</NavLink>
        <NavLink to="/kyc">توثيق KYC</NavLink>
        <NavLink to="/ads/new">نشر إعلان</NavLink>
        <NavLink to="/bot">بوت تلغرام</NavLink>
        {user?.isAdmin && <NavLink to="/admin">لوحة المدير</NavLink>}
      </nav>
      <div className="user-chip">
        {user ? (
          <>
            <span className={`badge ${user.kycStatus === "verified" ? "green" : "gold"}`}>
              {user.kycStatus === "verified" ? "موثّق" : user.kycStatus === "submitted" ? "KYC قيد المراجعة" : "غير موثّق"}
            </span>
            <span className="muted">{user.displayName}</span>
            <button className="ghost" onClick={logout}>
              خروج
            </button>
          </>
        ) : (
          <>
            <NavLink className="ghost" to="/login">
              دخول
            </NavLink>
            <NavLink className="btn" to="/register">
              إنشاء حساب
            </NavLink>
          </>
        )}
      </div>
    </header>
  );
}

function Market() {
  const meta = useMeta();
  const [stats, setStats] = useState({});
  const [ads, setAds] = useState([]);
  const [side, setSide] = useState("SELL");
  const [asset, setAsset] = useState("USDT");
  const [fiat, setFiat] = useState("SYP");
  const [payment, setPayment] = useState("");
  const nav = useNavigate();

  async function load() {
    const q = new URLSearchParams({ side, asset, fiat });
    if (payment) q.set("payment", payment);
    const [s, a] = await Promise.all([api("/api/stats"), api(`/api/ads?${q}`)]);
    setStats(s);
    setAds(a.ads);
  }

  useEffect(() => {
    load().catch(() => {});
  }, [side, asset, fiat, payment]);

  return (
    <div className="layout">
      <section className="hero">
        <div>
          <div className="badge gold">USDT شام · سوريا</div>
          <h1>اشترِ وبِع USDT عبر شام كاش بالليرة أو الدولار</h1>
          <p>
            منصة سورية لتداول USDT مقابل الليرة والدولار عبر شام كاش.
            العملة تُجمَّد في الضمان حتى يؤكد المشتري الدفع ثم يفرج البائع.
          </p>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn" onClick={() => nav("/register")}>
              ابدأ التداول
            </button>
            <button className="ghost" onClick={() => nav("/bot")}>
              فتح بوت تلغرام
            </button>
          </div>
          <div className="stats">
            <div className="stat">
              <b>{stats.users || 0}</b>
              <span>مستخدم</span>
            </div>
            <div className="stat">
              <b>{stats.ads || 0}</b>
              <span>إعلان نشط</span>
            </div>
            <div className="stat">
              <b>{stats.completed || 0}</b>
              <span>صفقة مكتملة</span>
            </div>
            <div className="stat">
              <b>{money(stats.volumeUsdt)}</b>
              <span>حجم USDT</span>
            </div>
          </div>
        </div>
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>كيف تعمل الصفقة</h3>
          <div className="steps">
            <div className="step">
              <span className="dot">1</span>
              <div>اختر إعلان شراء أو بيع وسعر مناسب.</div>
            </div>
            <div className="step">
              <span className="dot">2</span>
              <div>تُجمَّد العملة في الضمان تلقائياً.</div>
            </div>
            <div className="step">
              <span className="dot">3</span>
              <div>حوّل المبلغ عبر شام كاش بالليرة أو الدولار ثم أكد الدفع.</div>
            </div>
            <div className="step">
              <span className="dot">4</span>
              <div>البائع يتحقق ويفرج عن العملة إلى محفظتك.</div>
            </div>
          </div>
        </div>
      </section>

      <div className="panel">
        <div className="filters">
          <button className={`tab ${side === "SELL" ? "on" : ""}`} onClick={() => setSide("SELL")}>
            أشتري
          </button>
          <button className={`tab ${side === "BUY" ? "on" : ""}`} onClick={() => setSide("BUY")}>
            أبيع
          </button>
          <select value={asset} onChange={(e) => setAsset(e.target.value)}>
            {(meta.assets.length ? meta.assets : [{ symbol: "USDT" }]).map((a) => (
              <option key={a.symbol}>{a.symbol}</option>
            ))}
          </select>
          <select value={fiat} onChange={(e) => setFiat(e.target.value)}>
            {(meta.fiats.length ? meta.fiats : [{ code: "SYP" }]).map((f) => (
              <option key={f.code} value={f.code}>
                {f.code} {f.name || ""}
              </option>
            ))}
          </select>
          <select value={payment} onChange={(e) => setPayment(e.target.value)}>
            <option value="">كل طرق الدفع</option>
            {(meta.paymentTypes || []).map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
        <table>
          <thead>
            <tr>
              <th>المعلن</th>
              <th>السعر</th>
              <th>الحدود / المتاح</th>
              <th>الدفع</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {ads.map((ad) => (
              <tr key={ad.id}>
                <td>
                  <b>{ad.owner?.displayName}</b>
                  <div className="muted">
                    {ad.owner?.isMerchant ? "تاجر " : ""}
                    {ad.owner?.rating}% · {ad.owner?.completedTrades} صفقة
                  </div>
                </td>
                <td className={side === "SELL" ? "green" : "red"}>
                  <b className="mono">
                    {money(ad.price, 4)} {ad.fiat}
                  </b>
                </td>
                <td>
                  {money(ad.minAmount, 6)} - {money(ad.maxAmount, 6)} {ad.asset}
                  <div className="muted">متاح {money(ad.available, 6)}</div>
                </td>
                <td>
                  <div className="pay-chips">
                    {ad.paymentTypes.map((p) => (
                      <span className="badge" key={p}>
                        {meta.payName(p)}
                      </span>
                    ))}
                  </div>
                </td>
                <td>
                  <button className={`btn ${side === "BUY" ? "red" : "green"}`} onClick={() => nav(`/trade/${ad.id}`)}>
                    {side === "SELL" ? "شراء" : "بيع"} {ad.asset}
                  </button>
                </td>
              </tr>
            ))}
            {!ads.length && (
              <tr>
                <td colSpan="5" className="muted">
                  لا توجد إعلانات بهذه التصفية.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="footer">USDT شام · سوريا · شام كاش · SYP / USD</p>
    </div>
  );
}

function AuthForm({ mode }) {
  const { login, register } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ username: "", password: "", email: "", displayName: "" });
  const [err, setErr] = useState("");

  async function submit(e) {
    e.preventDefault();
    setErr("");
    try {
      if (mode === "login") await login(form.username, form.password);
      else await register(form);
      nav("/");
    } catch (ex) {
      setErr(ex.message);
    }
  }

  return (
    <div className="layout">
      <div className="auth-wrap panel">
        <h2>{mode === "login" ? "تسجيل الدخول" : "إنشاء حساب"}</h2>
        <form className="form" onSubmit={submit}>
          <input placeholder="اسم المستخدم أو البريد" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          {mode === "register" && (
            <>
              <input placeholder="البريد" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              <input placeholder="الاسم الظاهر" value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
            </>
          )}
          <input type="password" placeholder="كلمة المرور" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          {err && <div className="error">{err}</div>}
          <button className="btn">{mode === "login" ? "دخول" : "تسجيل"}</button>
        </form>
        {mode === "login" && (
          <p className="muted">
            تجريبي: demo / demo123 · merchant / merchant123 · buyer / buyer123 · المدير: admin / admin123
          </p>
        )}
      </div>
    </div>
  );
}

function Trade() {
  const { id } = useParams();
  const { user } = useAuth();
  const { payName } = useMeta();
  const nav = useNavigate();
  const [ad, setAd] = useState(null);
  const [amount, setAmount] = useState("");
  const [paymentType, setPaymentType] = useState("");
  const [err, setErr] = useState("");
  const [toast, setToast] = useState("");

  useEffect(() => {
    api(`/api/ads/${id}`)
      .then((d) => {
        setAd(d.ad);
        setPaymentType(d.ad.paymentTypes[0] || "");
      })
      .catch((e) => setErr(e.message));
  }, [id]);

  if (!ad) return <div className="layout">{err || "جاري التحميل..."}</div>;
  const qty = Number(amount);
  const fiatAmt = qty > 0 ? qty * ad.price : 0;
  const iBuy = ad.side === "SELL";

  async function place() {
    setErr("");
    if (!user) return nav("/login");
    try {
      const d = await api("/api/orders", {
        method: "POST",
        body: JSON.stringify({ adId: ad.id, amount: qty, paymentType })
      });
      setToast("تم إنشاء الصفقة");
      nav(`/orders/${d.order.id}`);
    } catch (e) {
      setErr(e.message);
    }
  }

  return (
    <div className="layout grid-2">
      <div className="panel">
        <h2>
          {iBuy ? "شراء" : "بيع"} {ad.asset} مقابل {ad.fiat}
        </h2>
        <p className="muted">
          المعلن: {ad.owner?.displayName} · تقييم {ad.owner?.rating}% · {ad.owner?.completedTrades} صفقة
        </p>
        <div className="form">
          <label>السعر</label>
          <input readOnly value={`${money(ad.price, 4)} ${ad.fiat}`} />
          <label>الكمية ({ad.asset})</label>
          <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={`${ad.minAmount} - ${ad.maxAmount}`} />
          <label>ستدفع / ستستلم بالفيات</label>
          <input readOnly value={`${money(fiatAmt)} ${ad.fiat}`} />
          <label>طريقة الدفع</label>
          <select value={paymentType} onChange={(e) => setPaymentType(e.target.value)}>
            {ad.paymentTypes.map((p) => (
              <option key={p} value={p}>
                {payName(p)}
              </option>
            ))}
          </select>
          {err && <div className="error">{err}</div>}
          <button className={`btn ${iBuy ? "green" : "red"}`} onClick={place}>
            {iBuy ? "شراء" : "بيع"} الآن
          </button>
        </div>
      </div>
      <div className="card">
        <h3>شروط المعلن</h3>
        <p>{ad.terms || "لا شروط إضافية."}</p>
        <p className="muted">مهلة الدفع: {ad.timeLimitMin} دقيقة</p>
        <p className="muted">المتاح: {money(ad.available, 6)} {ad.asset}</p>
      </div>
      <Toast text={toast} onDone={() => setToast("")} />
    </div>
  );
}

function Orders() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [orders, setOrders] = useState([]);
  useEffect(() => {
    if (!user) return;
    api("/api/orders").then((d) => setOrders(d.orders)).catch(() => {});
  }, [user]);
  if (!user) return <div className="layout">سجّل الدخول لعرض صفقاتك.</div>;
  return (
    <div className="layout">
      <div className="panel">
        <h2>صفقاتي</h2>
        <table>
          <thead>
            <tr>
              <th>رقم</th>
              <th>النوع</th>
              <th>الكمية</th>
              <th>الإجمالي</th>
              <th>الحالة</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} onClick={() => nav(`/orders/${o.id}`)} style={{ cursor: "pointer" }}>
                <td className="mono">{o.id.slice(-8)}</td>
                <td>{o.buyerId === user.id ? "شراء" : "بيع"}</td>
                <td>
                  {money(o.amount, 6)} {o.asset}
                </td>
                <td>
                  {money(o.fiatAmount)} {o.fiat}
                </td>
                <td>
                  <span className={`badge ${o.status === "completed" ? "green" : "gold"}`}>{STATUS[o.status]}</span>
                </td>
              </tr>
            ))}
            {!orders.length && (
              <tr>
                <td colSpan="5" className="muted">
                  لا صفقات بعد.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function OrderRoom() {
  const { id } = useParams();
  const { user } = useAuth();
  const { payName } = useMeta();
  const [data, setData] = useState(null);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");

  async function load() {
    const d = await api(`/api/orders/${id}`);
    setData(d);
  }

  useEffect(() => {
    load().catch((e) => setErr(e.message));
    const t = setInterval(() => load().catch(() => {}), 4000);
    return () => clearInterval(t);
  }, [id]);

  async function act(path, body) {
    setErr("");
    try {
      await api(`/api/orders/${id}/${path}`, { method: "POST", body: JSON.stringify(body || {}) });
      await load();
    } catch (e) {
      setErr(e.message);
    }
  }

  if (!data) return <div className="layout">{err || "جاري التحميل..."}</div>;
  const o = data.order;
  const iBuyer = user && o.buyerId === user.id;
  const iSeller = user && o.sellerId === user.id;

  return (
    <div className="layout grid-2">
      <div className="panel">
        <h2>صفقة {o.id.slice(-8)}</h2>
        <p>
          <span className="badge gold">{STATUS[o.status]}</span>
        </p>
        <p>
          {money(o.amount, 6)} {o.asset} @ {money(o.price, 4)} {o.fiat}
        </p>
        <p>
          الإجمالي: <b>{money(o.fiatAmount)} {o.fiat}</b>
        </p>
        <p>الدفع عبر: {payName(o.paymentType)} · {o.paymentLabel}</p>
        <pre className="card" style={{ whiteSpace: "pre-wrap" }}>
          {JSON.stringify(o.paymentDetails || {}, null, 2)}
        </pre>
        {err && <div className="error">{err}</div>}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {iBuyer && o.status === "pending_payment" && (
            <button className="btn green" onClick={() => act("paid")}>
              أكدت الدفع
            </button>
          )}
          {iSeller && (o.status === "paid" || o.status === "disputed") && (
            <button className="btn" onClick={() => act("release")}>
              إفراج عن العملة
            </button>
          )}
          {o.status === "pending_payment" && (
            <button className="ghost" onClick={() => act("cancel")}>
              إلغاء
            </button>
          )}
          {["pending_payment", "paid"].includes(o.status) && (
            <button className="btn red" onClick={() => act("dispute", { reason: "نزاع من الموقع" })}>
              فتح نزاع
            </button>
          )}
        </div>
      </div>
      <div className="chat">
        <div className="chat-log">
          {data.messages.map((m) => (
            <div key={m.id} className={`bubble ${m.userId === "system" ? "sys" : m.userId === user?.id ? "me" : ""}`}>
              {m.text}
            </div>
          ))}
        </div>
        <form
          className="chat-form"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!text.trim()) return;
            await act("messages", { text });
            setText("");
          }}
        >
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="اكتب رسالة..." />
          <button className="btn">إرسال</button>
        </form>
      </div>
    </div>
  );
}

function Wallet() {
  const { user } = useAuth();
  const meta = useMeta();
  const [wallets, setWallets] = useState([]);
  const [methods, setMethods] = useState([]);
  const [ads, setAds] = useState([]);
  const [deposits, setDeposits] = useState([]);
  const [dep, setDep] = useState({ asset: "USDT", amount: "100", txHash: "", fromAddress: "" });
  const [pm, setPm] = useState({ type: "SHAM_CASH", label: "", details: "{}" });
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState(false);

  async function load() {
    const [w, p, a, d] = await Promise.all([
      api("/api/wallet"),
      api("/api/payment-methods"),
      api("/api/ads/mine"),
      api("/api/deposits")
    ]);
    setWallets(w.wallets);
    setMethods(p.methods);
    setAds(a.ads);
    setDeposits(d.deposits);
  }

  useEffect(() => {
    if (user) load().catch(() => {});
  }, [user]);

  if (!user) return <div className="layout">سجّل الدخول.</div>;
  const depositCoins = (meta.assets || []).filter((a) => a.depositEnabled !== false);
  const address = meta.settings?.bep20Address || "";

  async function submitDeposit() {
    setErr("");
    try {
      await api("/api/deposits", {
        method: "POST",
        body: JSON.stringify({
          asset: dep.asset,
          amount: Number(dep.amount),
          txHash: dep.txHash,
          fromAddress: dep.fromAddress
        })
      });
      setDep({ ...dep, txHash: "", fromAddress: "" });
      load();
    } catch (e) {
      setErr(e.message);
    }
  }

  return (
    <div className="layout">
      <div className="grid-3">
        {wallets.map((w) => (
          <div className="card" key={w.asset}>
            <div className="muted">{w.asset}</div>
            <h2 className="mono">{money(w.available, 6)}</h2>
            <div className="muted">مجمّد {money(w.frozen, 6)}</div>
          </div>
        ))}
      </div>
      <div className="grid-2" style={{ marginTop: 16 }}>
        <div className="panel">
          <h3>إيداع BEP20</h3>
          <p className="muted">حوّل على شبكة Binance Smart Chain (BEP20) ثم أدخل هاش المعاملة. الرصيد يُضاف بعد موافقة المدير.</p>
          <div className="card" style={{ marginBottom: 12 }}>
            <div className="muted">عنوان المنصة</div>
            <div className="mono" style={{ wordBreak: "break-all" }}>{address}</div>
            <button
              className="ghost"
              style={{ marginTop: 8 }}
              onClick={() => {
                navigator.clipboard.writeText(address);
                setCopied(true);
              }}
            >
              {copied ? "تم النسخ" : "نسخ العنوان"}
            </button>
            <div className="muted" style={{ marginTop: 8 }}>
              الشبكة: {meta.settings?.bep20Network || "BEP20"} · الحد الأدنى {meta.settings?.minDeposit || 0}
            </div>
          </div>
          <div className="form">
            <select value={dep.asset} onChange={(e) => setDep({ ...dep, asset: e.target.value })}>
              {(depositCoins.length ? depositCoins : [{ symbol: "USDT" }]).map((a) => (
                <option key={a.symbol} value={a.symbol}>
                  {a.symbol} {a.name || ""}
                </option>
              ))}
            </select>
            <input value={dep.amount} onChange={(e) => setDep({ ...dep, amount: e.target.value })} placeholder="المبلغ" />
            <input value={dep.fromAddress} onChange={(e) => setDep({ ...dep, fromAddress: e.target.value })} placeholder="عنوان محفظتك 0x..." />
            <input value={dep.txHash} onChange={(e) => setDep({ ...dep, txHash: e.target.value })} placeholder="Tx Hash 0x..." />
            {err && <div className="error">{err}</div>}
            <button className="btn" onClick={submitDeposit}>
              إرسال طلب الإيداع
            </button>
          </div>
          <h4>طلبات الإيداع</h4>
          {deposits.map((d) => (
            <div key={d.id} className="muted" style={{ padding: "6px 0", borderBottom: "1px solid var(--line)" }}>
              {d.amount} {d.asset} · {d.status === "credited" ? "مقبول" : d.status === "rejected" ? "مرفوض" : "قيد المراجعة"}
              <div className="mono" style={{ fontSize: 11 }}>{d.txHash}</div>
            </div>
          ))}
        </div>
        <div className="panel">
          <h3>طرق الدفع</h3>
          {methods.filter((m) => m.active).map((m) => (
            <div key={m.id} className="badge" style={{ margin: 4 }}>
              {meta.payName(m.type)} · {m.label}
            </div>
          ))}
          <div className="form" style={{ marginTop: 10 }}>
            <select value={pm.type} onChange={(e) => setPm({ ...pm, type: e.target.value })}>
              {(meta.paymentTypes || []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <input placeholder="وصف" value={pm.label} onChange={(e) => setPm({ ...pm, label: e.target.value })} />
            <input placeholder='تفاصيل JSON مثل {"phone":"01.."}' value={pm.details} onChange={(e) => setPm({ ...pm, details: e.target.value })} />
            <button
              className="ghost"
              onClick={async () => {
                let details = {};
                try {
                  details = JSON.parse(pm.details || "{}");
                } catch {
                  details = { raw: pm.details };
                }
                await api("/api/payment-methods", { method: "POST", body: JSON.stringify({ ...pm, details }) });
                load();
              }}
            >
              إضافة طريقة
            </button>
          </div>
        </div>
      </div>
      <div className="panel" style={{ marginTop: 16 }}>
        <h3>إعلاناتي</h3>
        {ads.map((a) => (
          <div key={a.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--line)" }}>
            <span>
              {a.side} {a.asset}/{a.fiat} @ {a.price} · {STATUS[a.status] || a.status}
              {a.reviewNote ? ` — ${a.reviewNote}` : ""}
            </span>
            {["active", "paused"].includes(a.status) && (
              <button
                className="ghost"
                onClick={async () => {
                  await api(`/api/ads/${a.id}/toggle`, { method: "POST" });
                  load();
                }}
              >
                إيقاف/تشغيل
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function NewAd() {
  const { user } = useAuth();
  const meta = useMeta();
  const nav = useNavigate();
  const [form, setForm] = useState({
    side: "SELL",
    asset: "USDT",
    fiat: "SYP",
    price: "14800",
    minAmount: "50",
    maxAmount: "1000",
    available: "1000",
    paymentTypes: ["SHAM_CASH"],
    terms: "حوّل عبر شام كاش ثم اضغط تم الدفع.",
    timeLimitMin: 15
  });
  const [err, setErr] = useState("");
  const [done, setDone] = useState("");
  if (!user) return <div className="layout">سجّل الدخول لنشر إعلان.</div>;
  if (user.kycStatus !== "verified") {
    return (
      <div className="layout">
        <div className="panel">أكمل توثيق KYC قبل نشر إعلان. <NavLink to="/kyc">الذهاب للتوثيق</NavLink></div>
      </div>
    );
  }

  function togglePay(id) {
    setForm((f) => {
      const has = f.paymentTypes.includes(id);
      return { ...f, paymentTypes: has ? f.paymentTypes.filter((x) => x !== id) : [...f.paymentTypes, id] };
    });
  }

  async function submit(e) {
    e.preventDefault();
    setErr("");
    try {
      const data = await api("/api/ads", {
        method: "POST",
        body: JSON.stringify({
          ...form,
          price: Number(form.price),
          minAmount: Number(form.minAmount),
          maxAmount: Number(form.maxAmount),
          available: Number(form.available)
        })
      });
      if (data.ad?.status === "pending") {
        setDone("تم إرسال الإعلان. سيظهر في السوق بعد موافقة المدير.");
        return;
      }
      nav("/");
    } catch (ex) {
      setErr(ex.message);
    }
  }

  return (
    <div className="layout">
      <div className="panel auth-wrap" style={{ maxWidth: 560 }}>
        <h2>نشر إعلان P2P</h2>
        <p className="muted">الإعلان لا يظهر في السوق إلا بعد موافقة المدير.</p>
        {done && <p className="badge gold">{done}</p>}
        <form className="form" onSubmit={submit}>
          <select value={form.side} onChange={(e) => setForm({ ...form, side: e.target.value })}>
            <option value="SELL">أريد البيع (الآخرون يشترون)</option>
            <option value="BUY">أريد الشراء (الآخرون يبيعون)</option>
          </select>
          <select value={form.asset} onChange={(e) => setForm({ ...form, asset: e.target.value })}>
            {(meta.assets || []).map((a) => (
              <option key={a.symbol}>{a.symbol}</option>
            ))}
          </select>
          <select value={form.fiat} onChange={(e) => setForm({ ...form, fiat: e.target.value })}>
            {(meta.fiats || []).map((f) => (
              <option key={f.code} value={f.code}>
                {f.code} {f.name}
              </option>
            ))}
          </select>
          <input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="السعر" />
          <input value={form.minAmount} onChange={(e) => setForm({ ...form, minAmount: e.target.value })} placeholder="الحد الأدنى" />
          <input value={form.maxAmount} onChange={(e) => setForm({ ...form, maxAmount: e.target.value })} placeholder="الحد الأقصى" />
          <input value={form.available} onChange={(e) => setForm({ ...form, available: e.target.value })} placeholder="الكمية المتاحة" />
          <div className="pay-chips">
            {(meta.paymentTypes || []).map((p) => (
              <button type="button" key={p.id} className={`tab ${form.paymentTypes.includes(p.id) ? "on" : ""}`} onClick={() => togglePay(p.id)}>
                {p.name}
              </button>
            ))}
          </div>
          <textarea rows={3} value={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.value })} />
          {err && <div className="error">{err}</div>}
          <button className="btn">نشر</button>
        </form>
      </div>
    </div>
  );
}

const KYC_STATUS = {
  verified: "موثّق",
  submitted: "قيد المراجعة",
  rejected: "مرفوض",
  pending: "غير مكتمل"
};

function KycFileField({ label, hint, file, onPick }) {
  const [preview, setPreview] = useState("");
  useEffect(() => {
    if (!file || !file.type.startsWith("image/")) {
      setPreview("");
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  return (
    <label className="kyc-upload">
      <span>{label}</span>
      <small className="muted">{hint}</small>
      <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(e) => onPick(e.target.files?.[0] || null)} />
      {file && (
        <div className="kyc-preview">
          {preview ? <img src={preview} alt={label} /> : <b>{file.name}</b>}
          <span className="muted">{Math.round(file.size / 1024)} KB</span>
        </div>
      )}
    </label>
  );
}

function KycPage() {
  const { user, refresh } = useAuth();
  const [form, setForm] = useState({ fullName: "", nationalId: "", country: "SY", documentType: "id", phone: "", address: "" });
  const [files, setFiles] = useState({ id_front: null, id_back: null, selfie: null, extra: null });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (!user) return <div className="layout">سجّل الدخول لتوثيق الحساب.</div>;
  const status = user.kycStatus || "pending";
  async function submit(e) {
    e.preventDefault();
    setErr("");
    if (!files.id_front || !files.id_back || !files.selfie) {
      setErr("ارفع وجه الهوية وظهرها وصورة شخصية مع الوثيقة.");
      return;
    }
    setBusy(true);
    try {
      const payloadFiles = [];
      for (const [kind, file] of Object.entries(files)) {
        if (!file) continue;
        payloadFiles.push({ kind, name: file.name, data: await readFileAsDataUrl(file) });
      }
      await api("/api/kyc", { method: "POST", body: JSON.stringify({ ...form, files: payloadFiles }) });
      await refresh();
    } catch (ex) {
      setErr(ex.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="layout">
      <div className="panel" style={{ maxWidth: 720, margin: "0 auto" }}>
        <h2>توثيق الهوية KYC</h2>
        <p className="muted">ارفع صور الوثيقة والوجه. المدير يراجع الملف الكامل قبل القبول، ويحتفظ بنسخة للطباعة.</p>
        <p>
          الحالة: <span className={`badge ${status === "verified" ? "green" : "gold"}`}>{KYC_STATUS[status] || status}</span>
        </p>
        {user.kyc?.note && <p className="muted">ملاحظة الإدارة: {user.kyc.note}</p>}
        {status === "submitted" && (
          <div className="kyc-sent">
            <p>تم استلام ملفك وهو قيد مراجعة الإدارة. لن يُقبل إلا بعد الاطلاع على الصور.</p>
            <ul className="muted">
              {(user.kyc?.files || []).map((f) => (
                <li key={f.id}>{f.kind === "id_front" ? "وجه الهوية" : f.kind === "id_back" ? "ظهر الهوية" : f.kind === "selfie" ? "صورة شخصية" : "مستند إضافي"} — {f.name}</li>
              ))}
            </ul>
          </div>
        )}
        {status === "verified" && <p>حسابك موثّق. يمكنك التداول ونشر الإعلانات.</p>}
        {status !== "verified" && status !== "submitted" && (
          <form className="form" onSubmit={submit}>
            <input required placeholder="الاسم الكامل كما في الهوية" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            <input required placeholder="رقم الهوية / جواز السفر" value={form.nationalId} onChange={(e) => setForm({ ...form, nationalId: e.target.value })} />
            <input placeholder="رقم الهاتف" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <input placeholder="العنوان" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <select value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })}>
              <option value="SY">سوريا</option>
              <option value="OTHER">أخرى</option>
            </select>
            <select value={form.documentType} onChange={(e) => setForm({ ...form, documentType: e.target.value })}>
              <option value="id">بطاقة هوية</option>
              <option value="passport">جواز سفر</option>
              <option value="license">رخصة</option>
            </select>
            <div className="kyc-uploads">
              <KycFileField label="وجه الهوية *" hint="صورة واضحة للجهة الأمامية" file={files.id_front} onPick={(f) => setFiles({ ...files, id_front: f })} />
              <KycFileField label="ظهر الهوية *" hint="الجهة الخلفية أو صفحة الجواز الثانية" file={files.id_back} onPick={(f) => setFiles({ ...files, id_back: f })} />
              <KycFileField label="صورة شخصية مع الوثيقة *" hint="أمسك الهوية بجانب وجهك" file={files.selfie} onPick={(f) => setFiles({ ...files, selfie: f })} />
              <KycFileField label="مستند إضافي" hint="اختياري: إثبات سكن أو ملف PDF" file={files.extra} onPick={(f) => setFiles({ ...files, extra: f })} />
            </div>
            {err && <div className="error">{err}</div>}
            <button className="btn" disabled={busy}>{busy ? "جاري الرفع..." : "إرسال ملف التوثيق"}</button>
          </form>
        )}
      </div>
    </div>
  );
}

function AdminPage() {
  const { user } = useAuth();
  const { reload } = useMeta();
  const [tab, setTab] = useState("overview");
  const [overview, setOverview] = useState({});
  const [users, setUsers] = useState([]);
  const [kycs, setKycs] = useState([]);
  const [deposits, setDeposits] = useState([]);
  const [orders, setOrders] = useState([]);
  const [ads, setAds] = useState([]);
  const [catalog, setCatalog] = useState({ assets: [], fiats: [], paymentTypes: [], settings: {} });
  const [err, setErr] = useState("");
  const [assetForm, setAssetForm] = useState({ symbol: "", name: "", decimals: "18", contract: "" });
  const [fiatForm, setFiatForm] = useState({ code: "", name: "", symbol: "" });
  const [payForm, setPayForm] = useState({ id: "", name: "", fields: "account,name" });
  const [settings, setSettings] = useState({});
  const [kycOpen, setKycOpen] = useState(null);
  const [kycNote, setKycNote] = useState("");

  async function loadAll() {
    if (!user?.isAdmin) return;
    const [o, u, k, d, ord, a, c] = await Promise.all([
      api("/api/admin/overview"),
      api("/api/admin/users"),
      api("/api/admin/kyc"),
      api("/api/admin/deposits"),
      api("/api/admin/orders"),
      api("/api/admin/ads"),
      api("/api/admin/catalog")
    ]);
    setOverview(o);
    setUsers(u.users);
    setKycs(k.requests);
    setDeposits(d.deposits);
    setOrders(ord.orders);
    setAds(a.ads);
    setCatalog(c);
    setSettings(c.settings || {});
  }

  useEffect(() => {
    loadAll().catch((e) => setErr(e.message));
  }, [user]);

  if (!user) return <div className="layout">سجّل الدخول.</div>;
  if (!user.isAdmin) return <div className="layout">هذه الصفحة للمدير فقط.</div>;

  async function act(path, body) {
    setErr("");
    try {
      await api(path, { method: "POST", body: JSON.stringify(body || {}) });
      await loadAll();
      await reload();
    } catch (e) {
      setErr(e.message);
    }
  }

  return (
    <div className="layout">
      <h2>لوحة تحكم المدير</h2>
      <div className="filters">
        {[
          ["overview", "نظرة عامة"],
          ["kyc", "توثيق KYC"],
          ["deposits", "إيداعات BEP20"],
          ["payments", "طرق الدفع"],
          ["coins", "العملات"],
          ["users", "المستخدمون"],
          ["orders", "الصفقات"],
          ["ads", "الإعلانات"],
          ["settings", "إعدادات"]
        ].map(([id, label]) => (
          <button key={id} className={`tab ${tab === id ? "on" : ""}`} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </div>
      {err && <div className="error">{err}</div>}

      {tab === "overview" && (
        <div className="stats">
          <div className="stat"><b>{overview.users}</b><span>مستخدم</span></div>
          <div className="stat"><b>{overview.pendingKyc}</b><span>KYC معلّق</span></div>
          <div className="stat"><b>{overview.pendingDeposits}</b><span>إيداع معلّق</span></div>
          <div className="stat"><b>{overview.pendingAds}</b><span>إعلان معلّق</span></div>
          <div className="stat"><b>{overview.disputed}</b><span>نزاع</span></div>
        </div>
      )}

      {tab === "kyc" && (
        <div className="panel">
          <p className="muted">افتح الملف الكامل قبل أي قبول. الصور والمستندات ظاهرة أدناه، ونسخة الطباعة تحفظ سجلاً ورقياً.</p>
          <table>
            <thead><tr><th>المستخدم</th><th>الاسم</th><th>الهوية</th><th>الملفات</th><th>الحالة</th><th></th></tr></thead>
            <tbody>
              {kycs.map((r) => (
                <tr key={r.user.id}>
                  <td>{r.user.username}</td>
                  <td>{r.kyc?.fullName}</td>
                  <td className="mono">{r.kyc?.nationalId}</td>
                  <td>{(r.kyc?.files || []).length}</td>
                  <td>{KYC_STATUS[r.status] || r.status}</td>
                  <td>
                    <button className="btn dark" onClick={() => { setKycOpen(r); setKycNote(r.kyc?.note || ""); }}>فتح الملف</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {kycOpen && (
            <div className="kyc-dossier">
              <div className="kyc-dossier-head">
                <h3>ملف توثيق — {kycOpen.user.username}</h3>
                <div className="kyc-actions">
                  <a className="btn dark" href={authedUrl(kycOpen.printUrl)} target="_blank" rel="noreferrer">طباعة / حفظ PDF</a>
                  <button className="ghost" onClick={() => setKycOpen(null)}>إغلاق</button>
                </div>
              </div>
              <div className="kyc-meta">
                <div><span className="muted">الاسم الكامل</span><b>{kycOpen.kyc?.fullName || "—"}</b></div>
                <div><span className="muted">رقم الهوية</span><b className="mono">{kycOpen.kyc?.nationalId || "—"}</b></div>
                <div><span className="muted">نوع الوثيقة</span><b>{kycOpen.kyc?.documentLabel || kycOpen.kyc?.documentType}</b></div>
                <div><span className="muted">الدولة</span><b>{kycOpen.kyc?.country || "—"}</b></div>
                <div><span className="muted">الهاتف</span><b>{kycOpen.kyc?.phone || "—"}</b></div>
                <div><span className="muted">العنوان</span><b>{kycOpen.kyc?.address || "—"}</b></div>
                <div><span className="muted">البريد</span><b>{kycOpen.user.email || "—"}</b></div>
                <div><span className="muted">تلغرام</span><b>{kycOpen.user.telegramId || "—"}</b></div>
                <div><span className="muted">الحالة</span><b>{KYC_STATUS[kycOpen.status] || kycOpen.status}</b></div>
              </div>
              <div className="kyc-gallery">
                {(kycOpen.kyc?.files || []).map((f) => (
                  <figure key={f.id}>
                    {String(f.mime || "").startsWith("image/") ? (
                      <a href={authedUrl(f.url)} target="_blank" rel="noreferrer">
                        <img src={authedUrl(f.url)} alt={f.label} />
                      </a>
                    ) : (
                      <a className="btn dark" href={authedUrl(f.url)} target="_blank" rel="noreferrer">فتح {f.name}</a>
                    )}
                    <figcaption>{f.label} — {f.name}</figcaption>
                  </figure>
                ))}
                {!(kycOpen.kyc?.files || []).length && <p className="muted">لا توجد صور أو مستندات مرفوعة في هذا الطلب.</p>}
              </div>
              {kycOpen.status === "submitted" && (
                <div className="form" style={{ maxWidth: 520 }}>
                  <textarea rows="3" placeholder="ملاحظة للسجل أو سبب الرفض" value={kycNote} onChange={(e) => setKycNote(e.target.value)} />
                  <div className="kyc-actions">
                    <button
                      className="btn green"
                      disabled={!(kycOpen.kyc?.files || []).length}
                      onClick={async () => {
                        await act(`/api/admin/kyc/${kycOpen.user.id}`, { action: "approve", note: kycNote });
                        setKycOpen(null);
                      }}
                    >
                      قبول بعد الاطلاع
                    </button>
                    <button
                      className="btn red"
                      onClick={async () => {
                        await act(`/api/admin/kyc/${kycOpen.user.id}`, { action: "reject", note: kycNote || "وثائق غير مكتملة" });
                        setKycOpen(null);
                      }}
                    >
                      رفض
                    </button>
                  </div>
                  {!(kycOpen.kyc?.files || []).length && <p className="error">لا يمكن القبول بدون صور الوثيقة.</p>}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {tab === "deposits" && (
        <div className="panel">
          <table>
            <thead><tr><th>المستخدم</th><th>المبلغ</th><th>الهاش</th><th>الحالة</th><th></th></tr></thead>
            <tbody>
              {deposits.map((d) => (
                <tr key={d.id}>
                  <td>{d.user?.username}</td>
                  <td>{d.amount} {d.asset}</td>
                  <td className="mono" style={{ fontSize: 11 }}>{d.txHash}</td>
                  <td>{d.status === "credited" ? "مقبول" : d.status === "rejected" ? "مرفوض" : "معلّق"}</td>
                  <td>
                    {d.status === "pending" && (
                      <>
                        <button className="btn green" onClick={() => act(`/api/admin/deposits/${d.id}`, { action: "approve" })}>إضافة الرصيد</button>
                        {" "}
                        <button className="btn red" onClick={() => act(`/api/admin/deposits/${d.id}`, { action: "reject", note: "لم يظهر التحويل" })}>رفض</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "payments" && (
        <div className="panel">
          <h3>طرق الدفع في المنصة</h3>
          {catalog.paymentTypes.map((p) => (
            <div key={p.id} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--line)" }}>
              <span>{p.name} ({p.id}) {p.enabled ? "" : " - معطّلة"}</span>
              <button className="ghost" onClick={() => act(`/api/admin/payment-types/${p.id}`, { enabled: !p.enabled })}>
                {p.enabled ? "إيقاف" : "تفعيل"}
              </button>
            </div>
          ))}
          <h4>إضافة طريقة دفع</h4>
          <div className="form">
            <input placeholder="المعرف مثل CASH" value={payForm.id} onChange={(e) => setPayForm({ ...payForm, id: e.target.value })} />
            <input placeholder="الاسم" value={payForm.name} onChange={(e) => setPayForm({ ...payForm, name: e.target.value })} />
            <input placeholder="الحقول" value={payForm.fields} onChange={(e) => setPayForm({ ...payForm, fields: e.target.value })} />
            <button className="btn" onClick={() => act("/api/admin/payment-types", payForm)}>إضافة</button>
          </div>
        </div>
      )}

      {tab === "coins" && (
        <div className="grid-2">
          <div className="panel">
            <h3>العملات الرقمية (BEP20)</h3>
            {catalog.assets.map((a) => (
              <div key={a.symbol} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--line)" }}>
                <span>{a.symbol} · {a.name} {a.enabled ? "" : "(متوقفة)"}</span>
                <span>
                  <button className="ghost" onClick={() => act(`/api/admin/assets/${a.symbol}`, { enabled: !a.enabled })}>{a.enabled ? "إيقاف" : "تفعيل"}</button>
                  {" "}
                  <button className="ghost" onClick={() => act(`/api/admin/assets/${a.symbol}`, { depositEnabled: !a.depositEnabled })}>{a.depositEnabled ? "إيقاف الإيداع" : "تفعيل الإيداع"}</button>
                </span>
              </div>
            ))}
            <h4>إضافة عملة</h4>
            <div className="form">
              <input placeholder="الرمز USDT" value={assetForm.symbol} onChange={(e) => setAssetForm({ ...assetForm, symbol: e.target.value })} />
              <input placeholder="الاسم" value={assetForm.name} onChange={(e) => setAssetForm({ ...assetForm, name: e.target.value })} />
              <input placeholder="العقد 0x..." value={assetForm.contract} onChange={(e) => setAssetForm({ ...assetForm, contract: e.target.value })} />
              <button className="btn" onClick={() => act("/api/admin/assets", assetForm)}>إضافة عملة</button>
            </div>
          </div>
          <div className="panel">
            <h3>العملات الورقية</h3>
            {catalog.fiats.map((f) => (
              <div key={f.code} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--line)" }}>
                <span>{f.code} · {f.name}</span>
                <button className="ghost" onClick={() => act(`/api/admin/fiats/${f.code}`, { enabled: !f.enabled })}>{f.enabled ? "إيقاف" : "تفعيل"}</button>
              </div>
            ))}
            <h4>إضافة عملة ورقية</h4>
            <div className="form">
              <input placeholder="الرمز MAD" value={fiatForm.code} onChange={(e) => setFiatForm({ ...fiatForm, code: e.target.value })} />
              <input placeholder="الاسم" value={fiatForm.name} onChange={(e) => setFiatForm({ ...fiatForm, name: e.target.value })} />
              <input placeholder="الرمز المختصر" value={fiatForm.symbol} onChange={(e) => setFiatForm({ ...fiatForm, symbol: e.target.value })} />
              <button className="btn" onClick={() => act("/api/admin/fiats", fiatForm)}>إضافة</button>
            </div>
          </div>
        </div>
      )}

      {tab === "users" && (
        <div className="panel">
          <table>
            <thead><tr><th>المستخدم</th><th>KYC</th><th>تاجر</th><th>مدير</th><th></th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.displayName}<div className="muted">{u.username}</div></td>
                  <td>{u.kycStatus}</td>
                  <td>{u.isMerchant ? "نعم" : "لا"}</td>
                  <td>{u.isAdmin ? "نعم" : "لا"}</td>
                  <td>
                    <button className="ghost" onClick={() => act(`/api/admin/users/${u.id}`, { isMerchant: !u.isMerchant })}>تاجر</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "orders" && (
        <div className="panel">
          <table>
            <thead><tr><th>رقم</th><th>الأطراف</th><th>المبلغ</th><th>الحالة</th><th></th></tr></thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td className="mono">{o.id.slice(-8)}</td>
                  <td>{o.buyer?.username} / {o.seller?.username}</td>
                  <td>{o.amount} {o.asset}</td>
                  <td>{STATUS[o.status] || o.status}</td>
                  <td>
                    {["paid", "disputed"].includes(o.status) && (
                      <button className="btn green" onClick={() => act(`/api/orders/${o.id}/release`)}>إفراج</button>
                    )}
                    {o.status !== "completed" && o.status !== "cancelled" && (
                      <button className="ghost" onClick={() => act(`/api/orders/${o.id}/cancel`)}>إلغاء</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "ads" && (
        <div className="panel">
          <p className="muted">الإعلانات الجديدة لا تظهر في السوق حتى توافق عليها.</p>
          {ads.map((a) => (
            <div key={a.id} style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--line)", flexWrap: "wrap" }}>
              <div>
                <b>{a.owner?.username}</b> · {a.side === "SELL" ? "بيع" : "شراء"} {a.asset}/{a.fiat} @ {a.price}
                <div className="muted">الحد {a.minAmount}-{a.maxAmount} · المتاح {a.available} · {STATUS[a.status] || a.status}</div>
                {a.terms && <div className="muted">{a.terms}</div>}
                {a.reviewNote && <div className="muted">ملاحظة: {a.reviewNote}</div>}
              </div>
              <div className="kyc-actions">
                {a.status === "pending" && (
                  <>
                    <button className="btn green" onClick={() => act(`/api/admin/ads/${a.id}/review`, { action: "approve" })}>قبول</button>
                    <button className="btn red" onClick={() => act(`/api/admin/ads/${a.id}/review`, { action: "reject", note: "لم تتم الموافقة على الإعلان" })}>رفض</button>
                  </>
                )}
                {["active", "paused"].includes(a.status) && (
                  <button className="ghost" onClick={() => act(`/api/admin/ads/${a.id}/toggle`)}>إيقاف/تشغيل</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "settings" && (
        <div className="panel" style={{ maxWidth: 560 }}>
          <h3>عنوان إيداع BEP20</h3>
          <div className="form">
            <input placeholder="اسم البوت بدون @" value={settings.telegramBotUsername || ""} onChange={(e) => setSettings({ ...settings, telegramBotUsername: e.target.value })} />
            <input placeholder="رابط التطبيق المصغّر https" value={settings.webAppUrl || ""} onChange={(e) => setSettings({ ...settings, webAppUrl: e.target.value })} />
            <input value={settings.bep20Address || ""} onChange={(e) => setSettings({ ...settings, bep20Address: e.target.value })} />
            <input value={settings.bep20Network || ""} onChange={(e) => setSettings({ ...settings, bep20Network: e.target.value })} />
            <input value={settings.minDeposit ?? ""} onChange={(e) => setSettings({ ...settings, minDeposit: e.target.value })} placeholder="الحد الأدنى" />
            <label><input type="checkbox" checked={!!settings.requireKycForTrade} onChange={(e) => setSettings({ ...settings, requireKycForTrade: e.target.checked })} /> KYC للتداول</label>
            <label><input type="checkbox" checked={!!settings.requireKycForAd} onChange={(e) => setSettings({ ...settings, requireKycForAd: e.target.checked })} /> KYC لنشر الإعلان</label>
            <label><input type="checkbox" checked={!!settings.requireKycForDeposit} onChange={(e) => setSettings({ ...settings, requireKycForDeposit: e.target.checked })} /> KYC للإيداع</label>
            <button className="btn" onClick={() => act("/api/admin/settings", { ...settings, minDeposit: Number(settings.minDeposit) })}>حفظ الإعدادات</button>
          </div>
        </div>
      )}
    </div>
  );
}

function BotPage() {
  const { user } = useAuth();
  const meta = useMeta();
  const [code, setCode] = useState("");
  const botUser = meta.settings?.telegramBotUsername || "EntrepreneurMA_bot";
  const botLink = `https://t.me/${botUser}`;
  async function link() {
    const d = await api("/api/telegram/link", { method: "POST" });
    setCode(d.code);
  }
  return (
    <div className="layout">
      <div className="panel">
        <h2>بوت تلغرام USDT شام</h2>
        <p>تداول USDT مقابل الليرة السورية والدولار عبر شام كاش من تيليجرام.</p>
        <p>
          اسم البوت: <b className="mono">@{botUser}</b>
        </p>
        <a className="btn" href={botLink} target="_blank" rel="noreferrer">
          فتح البوت على تلغرام
        </a>
        <ol>
          <li>افتح @{botUser} من الرابط أعلاه.</li>
          <li>أرسل /start ثم اختر شراء USDT أو بيع USDT.</li>
          <li>ادفع عبر شام كاش بالليرة أو الدولار.</li>
        </ol>
        {user && (
          <div>
            <button className="btn dark" onClick={link}>
              إنشاء رمز ربط بالحساب
            </button>
            {code && (
              <p className="mono">
                أرسل للبوت: /start LINK_{code}
              </p>
            )}
          </div>
        )}
        <p className="muted">لتشغيل البوت ضع توكن BotFather ثم: TELEGRAM_BOT_TOKEN=xxx node backend/bot.js</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <Topbar />
      <Routes>
        <Route path="/" element={<Market />} />
        <Route path="/login" element={<AuthForm mode="login" />} />
        <Route path="/register" element={<AuthForm mode="register" />} />
        <Route path="/trade/:id" element={<Trade />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/orders/:id" element={<OrderRoom />} />
        <Route path="/wallet" element={<Wallet />} />
        <Route path="/kyc" element={<KycPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/ads/new" element={<NewAd />} />
        <Route path="/bot" element={<BotPage />} />
      </Routes>
    </>
  );
}
