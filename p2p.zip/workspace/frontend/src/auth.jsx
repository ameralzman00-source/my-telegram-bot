import React, { createContext, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  async function refresh() {
    if (!getToken()) {
      setUser(null);
      setReady(true);
      return;
    }
    try {
      const data = await api("/api/me");
      setUser(data.user);
    } catch {
      setToken("");
      setUser(null);
    } finally {
      setReady(true);
    }
  }

  useEffect(() => {
    const tg = window.Telegram && window.Telegram.WebApp;
    if (tg) {
      try {
        tg.ready();
        tg.expand();
        if (tg.setHeaderColor) tg.setHeaderColor("#0b0e11");
        if (tg.setBackgroundColor) tg.setBackgroundColor("#0b0e11");
      } catch {
        /* ignore */
      }
    }
    async function boot() {
      if (!getToken() && tg && tg.initData) {
        try {
          const data = await api("/api/auth/telegram", {
            method: "POST",
            body: JSON.stringify({ initData: tg.initData })
          });
          setToken(data.token);
          setUser(data.user);
          setReady(true);
          return;
        } catch {
          /* fall through to normal session */
        }
      }
      await refresh();
    }
    boot();
  }, []);

  async function login(username, password) {
    const data = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }

  async function register(payload) {
    const data = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(payload)
    });
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }

  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch {
      /* ignore */
    }
    setToken("");
    setUser(null);
  }

  return (
    <AuthCtx.Provider value={{ user, ready, login, register, logout, refresh }}>
      {children}
    </AuthCtx.Provider>
  );
}

export function useAuth() {
  return useContext(AuthCtx);
}
