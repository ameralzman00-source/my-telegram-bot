const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");

function hashPassword(password, salt) {
  const s = salt || crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, s, 64).toString("hex");
  return { salt: s, hash };
}

function verifyPassword(password, salt, hash) {
  const check = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex"));
}

function uid(prefix) {
  return `${prefix}_${crypto.randomBytes(8).toString("hex")}`;
}

function now() {
  return Date.now();
}

function defaultAssets() {
  return [
    { symbol: "USDT", name: "Tether", decimals: 2, network: "BEP20", contract: "0x55d398326f99059fF775485246999027B3197955", enabled: true, depositEnabled: true },
    { symbol: "USDC", name: "USD Coin", decimals: 2, network: "BEP20", contract: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", enabled: true, depositEnabled: true },
    { symbol: "BNB", name: "BNB", decimals: 6, network: "BEP20", contract: "native", enabled: true, depositEnabled: true },
    { symbol: "ETH", name: "Ethereum", decimals: 6, network: "BEP20", contract: "0x2170Ed0880ac9A755fd29B2688956BD959F933F8", enabled: true, depositEnabled: true },
    { symbol: "BTC", name: "Bitcoin", decimals: 8, network: "BEP20", contract: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c", enabled: true, depositEnabled: true }
  ];
}

function defaultFiats() {
  return [
    { code: "SYP", name: "ليرة سورية", symbol: "ل.س", enabled: true },
    { code: "USD", name: "دولار أمريكي", symbol: "$", enabled: true }
  ];
}

function defaultPaymentTypes() {
  return [
    { id: "SHAM_CASH", name: "شام كاش", icon: "wallet", enabled: true, fields: "phone,name,account" }
  ];
}

function defaultSettings() {
  return {
    brand: "USDT شام",
    country: "SY",
    telegramBotUsername: "EntrepreneurMA_bot",
    ownerTelegramId: "1441524960",
    webAppUrl: "https://5173-99eb0b994a1f14ee.monkeycode-ai.live",
    bep20Address: "0x4e5e8A2C91B6F3d1A0c7E4b9F8D2a6C1B0E3F847",
    bep20Network: "BSC BEP20",
    minDeposit: 10,
    requireKycForTrade: true,
    requireKycForAd: true,
    requireKycForDeposit: false,
    requireMerchantForAd: true,
    advancedKycUsdt: 2000
  };
}

function emptyDb() {
  return {
    users: [],
    wallets: [],
    paymentMethods: [],
    ads: [],
    orders: [],
    messages: [],
    notifications: [],
    sessions: [],
    assets: defaultAssets(),
    fiats: defaultFiats(),
    paymentTypes: defaultPaymentTypes(),
    settings: defaultSettings(),
    kycRequests: [],
    deposits: []
  };
}

function seedDb() {
  const demo = hashPassword("demo123");
  const merchant = hashPassword("merchant123");
  const admin = hashPassword("admin123");
  const buyer = hashPassword("buyer123");

  const users = [
    {
      id: "u_demo",
      username: "demo",
      email: "demo@p2p.local",
      displayName: "مستخدم تجريبي",
      passwordHash: demo.hash,
      passwordSalt: demo.salt,
      telegramId: null,
      telegramUsername: null,
      isMerchant: false,
      isAdmin: false,
      kycStatus: "verified",
      kyc: { fullName: "مستخدم تجريبي", nationalId: "01010012345", country: "SY", submittedAt: now() - 86400000 * 39, reviewedAt: now() - 86400000 * 38, note: "" },
      rating: 98.5,
      completedTrades: 12,
      createdAt: now() - 86400000 * 40
    },
    {
      id: "u_merchant",
      username: "merchant",
      email: "merchant@p2p.local",
      displayName: "تاجر الشام",
      passwordHash: merchant.hash,
      passwordSalt: merchant.salt,
      telegramId: null,
      telegramUsername: null,
      isMerchant: true,
      isAdmin: false,
      kycStatus: "verified",
      kyc: { fullName: "تاجر الشام", nationalId: "01010019876", country: "SY", submittedAt: now() - 86400000 * 390, reviewedAt: now() - 86400000 * 389, note: "" },
      rating: 99.7,
      completedTrades: 1840,
      createdAt: now() - 86400000 * 400
    },
    {
      id: "u_admin",
      username: "admin",
      email: "admin@p2p.local",
      displayName: "الإدارة",
      passwordHash: admin.hash,
      passwordSalt: admin.salt,
      telegramId: "1441524960",
      telegramUsername: null,
      isMerchant: true,
      isAdmin: true,
      kycStatus: "verified",
      kyc: { fullName: "مدير المنصة", nationalId: "01010010001", country: "SY", submittedAt: now() - 86400000 * 499, reviewedAt: now() - 86400000 * 499, note: "" },
      rating: 100,
      completedTrades: 50,
      createdAt: now() - 86400000 * 500
    },
    {
      id: "u_buyer",
      username: "buyer",
      email: "buyer@p2p.local",
      displayName: "مشتري سريع",
      passwordHash: buyer.hash,
      passwordSalt: buyer.salt,
      telegramId: null,
      telegramUsername: null,
      isMerchant: false,
      isAdmin: false,
      kycStatus: "verified",
      kyc: { fullName: "مشتري سريع", nationalId: "01010015555", country: "SY", submittedAt: now() - 86400000 * 85, reviewedAt: now() - 86400000 * 84, note: "" },
      rating: 97.2,
      completedTrades: 34,
      createdAt: now() - 86400000 * 90
    }
  ];

  const extraMerchants = [
    ["u_m1", "shamdesk", "مكتب الشام", 99.8, 3200],
    ["u_m2", "damascusex", "دمشق إكسشينج", 99.4, 910],
    ["u_m3", "aleppocash", "حلب كاش", 98.9, 540],
    ["u_m4", "baradap2p", "بردى P2P", 99.1, 1280],
    ["u_m5", "shamotc", "شام OTC", 99.9, 4100],
    ["u_m6", "reefcash", "ريف كاش", 98.6, 220]
  ];

  extraMerchants.forEach(([id, username, displayName, rating, trades]) => {
    const p = hashPassword("pass123");
    users.push({
      id,
      username,
      email: `${username}@p2p.local`,
      displayName,
      passwordHash: p.hash,
      passwordSalt: p.salt,
      telegramId: null,
      telegramUsername: null,
      isMerchant: true,
      isAdmin: false,
      kycStatus: "verified",
      kyc: { fullName: displayName, nationalId: "", country: "SY", submittedAt: now(), reviewedAt: now(), note: "" },
      rating,
      completedTrades: trades,
      createdAt: now() - 86400000 * (100 + trades / 10)
    });
  });

  const wallets = [];
  users.forEach((u) => {
    const isMerchant = u.isMerchant;
    wallets.push(
      {
        userId: u.id,
        asset: "USDT",
        available: isMerchant ? 250000 : u.id === "u_demo" ? 1250.5 : 320,
        frozen: 0
      },
      {
        userId: u.id,
        asset: "BTC",
        available: isMerchant ? 2.15 : 0.012,
        frozen: 0
      },
      {
        userId: u.id,
        asset: "ETH",
        available: isMerchant ? 18.4 : 0.45,
        frozen: 0
      },
      {
        userId: u.id,
        asset: "USDC",
        available: isMerchant ? 80000 : 200,
        frozen: 0
      }
    );
  });

  const paymentMethods = [
    {
      id: "pm_m_sham",
      userId: "u_merchant",
      type: "SHAM_CASH",
      label: "شام كاش - تاجر الشام",
      details: { phone: "0933123456", name: "تاجر الشام", account: "SHAM-100245" },
      active: true
    },
    {
      id: "pm_demo_sham",
      userId: "u_demo",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0944987654", name: "مستخدم تجريبي", account: "SHAM-203998" },
      active: true
    },
    {
      id: "pm_buyer_sham",
      userId: "u_buyer",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0955111222", name: "مشتري سريع", account: "SHAM-551122" },
      active: true
    },
    {
      id: "pm_m1_sham",
      userId: "u_m1",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0933444555", name: "مكتب الشام", account: "SHAM-448901" },
      active: true
    },
    {
      id: "pm_m2_sham",
      userId: "u_m2",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0966777888", name: "دمشق إكسشينج", account: "SHAM-667788" },
      active: true
    },
    {
      id: "pm_m3_sham",
      userId: "u_m3",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0988122390", name: "حلب كاش", account: "SHAM-778812" },
      active: true
    },
    {
      id: "pm_m4_sham",
      userId: "u_m4",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0922111223", name: "بردى P2P", account: "SHAM-221112" },
      active: true
    },
    {
      id: "pm_m5_sham",
      userId: "u_m5",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0999888776", name: "شام OTC", account: "SHAM-998877" },
      active: true
    },
    {
      id: "pm_m6_sham",
      userId: "u_m6",
      type: "SHAM_CASH",
      label: "شام كاش",
      details: { phone: "0944000111", name: "ريف كاش", account: "SHAM-440001" },
      active: true
    }
  ];

  const ads = [
    {
      id: "ad_1",
      userId: "u_merchant",
      side: "SELL",
      asset: "USDT",
      fiat: "SYP",
      price: 14850,
      minAmount: 50,
      maxAmount: 5000,
      available: 42000,
      paymentTypes: ["SHAM_CASH"],
      terms: "حوّل عبر شام كاش ثم اضغط تم الدفع. يُفرج عن USDT بعد التحقق.",
      timeLimitMin: 15,
      status: "active",
      createdAt: now() - 86400000 * 10
    },
    {
      id: "ad_2",
      userId: "u_merchant",
      side: "BUY",
      asset: "USDT",
      fiat: "SYP",
      price: 14550,
      minAmount: 100,
      maxAmount: 8000,
      available: 20000,
      paymentTypes: ["SHAM_CASH"],
      terms: "أرسل USDT أولاً. تحويل شام كاش خلال 10 دقائق بعد الاستلام.",
      timeLimitMin: 20,
      status: "active",
      createdAt: now() - 86400000 * 8
    },
    {
      id: "ad_3",
      userId: "u_m1",
      side: "SELL",
      asset: "USDT",
      fiat: "SYP",
      price: 14920,
      minAmount: 200,
      maxAmount: 15000,
      available: 88000,
      paymentTypes: ["SHAM_CASH"],
      terms: "شام كاش فقط. لا تستخدم حساب طرف ثالث.",
      timeLimitMin: 30,
      status: "active",
      createdAt: now() - 86400000 * 20
    },
    {
      id: "ad_4",
      userId: "u_m2",
      side: "SELL",
      asset: "USDT",
      fiat: "SYP",
      price: 14780,
      minAmount: 20,
      maxAmount: 2000,
      available: 9500,
      paymentTypes: ["SHAM_CASH"],
      terms: "شام كاش. أرسل لقطة الشاشة في المحادثة.",
      timeLimitMin: 10,
      status: "active",
      createdAt: now() - 86400000 * 3
    },
    {
      id: "ad_5",
      userId: "u_m3",
      side: "SELL",
      asset: "USDT",
      fiat: "USD",
      price: 1.02,
      minAmount: 50,
      maxAmount: 3000,
      available: 18000,
      paymentTypes: ["SHAM_CASH"],
      terms: "بيع USDT مقابل دولار عبر شام كاش.",
      timeLimitMin: 20,
      status: "active",
      createdAt: now() - 86400000 * 5
    },
    {
      id: "ad_6",
      userId: "u_m5",
      side: "SELL",
      asset: "USDT",
      fiat: "USD",
      price: 1.015,
      minAmount: 100,
      maxAmount: 20000,
      available: 150000,
      paymentTypes: ["SHAM_CASH"],
      terms: "شام كاش بالدولار. الإفراج فوري بعد التأكيد.",
      timeLimitMin: 15,
      status: "active",
      createdAt: now() - 86400000 * 2
    },
    {
      id: "ad_7",
      userId: "u_m5",
      side: "BUY",
      asset: "USDT",
      fiat: "USD",
      price: 0.995,
      minAmount: 200,
      maxAmount: 30000,
      available: 90000,
      paymentTypes: ["SHAM_CASH"],
      terms: "نشتري USDT مقابل دولار عبر شام كاش.",
      timeLimitMin: 20,
      status: "active",
      createdAt: now() - 86400000 * 2
    },
    {
      id: "ad_8",
      userId: "u_m6",
      side: "SELL",
      asset: "USDT",
      fiat: "SYP",
      price: 14690,
      minAmount: 30,
      maxAmount: 2500,
      available: 12000,
      paymentTypes: ["SHAM_CASH"],
      terms: "ريف كاش عبر شام كاش. لا تذكر كلمة كريبتو في الملاحظة.",
      timeLimitMin: 12,
      status: "active",
      createdAt: now() - 86400000 * 7
    },
    {
      id: "ad_9",
      userId: "u_m4",
      side: "BUY",
      asset: "USDT",
      fiat: "SYP",
      price: 14480,
      minAmount: 50,
      maxAmount: 4000,
      available: 16000,
      paymentTypes: ["SHAM_CASH"],
      terms: "نشتري USDT بالليرة السورية عبر شام كاش.",
      timeLimitMin: 15,
      status: "active",
      createdAt: now() - 86400000 * 4
    },
    {
      id: "ad_10",
      userId: "u_m2",
      side: "BUY",
      asset: "USDT",
      fiat: "USD",
      price: 0.99,
      minAmount: 50,
      maxAmount: 3000,
      available: 12000,
      paymentTypes: ["SHAM_CASH"],
      terms: "شراء سريع عبر شام كاش بالدولار.",
      timeLimitMin: 12,
      status: "active",
      createdAt: now() - 86400000 * 1
    },
    {
      id: "ad_11",
      userId: "u_m1",
      side: "SELL",
      asset: "USDT",
      fiat: "SYP",
      price: 15010,
      minAmount: 100,
      maxAmount: 8000,
      available: 35000,
      paymentTypes: ["SHAM_CASH"],
      terms: "مكتب الشام. شام كاش فقط.",
      timeLimitMin: 20,
      status: "active",
      createdAt: now() - 86400000 * 6
    },
    {
      id: "ad_12",
      userId: "u_merchant",
      side: "SELL",
      asset: "USDT",
      fiat: "USD",
      price: 1.008,
      minAmount: 50,
      maxAmount: 4000,
      available: 22000,
      paymentTypes: ["SHAM_CASH"],
      terms: "بيع USDT مقابل دولار عبر شام كاش.",
      timeLimitMin: 15,
      status: "active",
      createdAt: now() - 86400000 * 1
    }
  ];

  ads.forEach((ad) => {
    if (ad.side !== "SELL") return;
    const w = wallets.find((x) => x.userId === ad.userId && x.asset === ad.asset);
    if (!w) return;
    const amt = Math.min(w.available, ad.available);
    w.available = Math.round((w.available - amt) * 1e8) / 1e8;
    w.frozen = Math.round((w.frozen + amt) * 1e8) / 1e8;
  });

  return {
    users,
    wallets,
    paymentMethods,
    ads,
    orders: [],
    messages: [],
    notifications: [],
    sessions: [],
    assets: defaultAssets(),
    fiats: defaultFiats(),
    paymentTypes: defaultPaymentTypes(),
    settings: defaultSettings(),
    kycRequests: [],
    deposits: []
  };
}

let db = emptyDb();

function bindOwnerAdmin(data) {
  const ownerId = String((data.settings && data.settings.ownerTelegramId) || "1441524960");
  const admin = (data.users || []).find((u) => u.username === "admin") || (data.users || []).find((u) => u.isAdmin);
  if (!admin) return data;
  const extra = (data.users || []).find((u) => u.id !== admin.id && String(u.telegramId) === ownerId);
  admin.telegramId = ownerId;
  admin.isAdmin = true;
  admin.isMerchant = true;
  admin.kycStatus = "verified";
  if (extra) {
    if (extra.telegramUsername) admin.telegramUsername = extra.telegramUsername;
    if (extra.displayName && extra.displayName !== extra.username) admin.displayName = extra.displayName;
    extra.telegramId = null;
    extra.isAdmin = false;
  }
  return data;
}

function migrate(data) {
  if (!Array.isArray(data.assets) || !data.assets.length) data.assets = defaultAssets();
  data.fiats = defaultFiats();
  data.paymentTypes = defaultPaymentTypes();
  data.settings = {
    ...defaultSettings(),
    ...(data.settings || {}),
    brand: "USDT شام",
    country: "SY",
    telegramBotUsername: (data.settings && data.settings.telegramBotUsername) || "EntrepreneurMA_bot",
    ownerTelegramId: (data.settings && data.settings.ownerTelegramId) || "1441524960",
    webAppUrl: (data.settings && data.settings.webAppUrl) || "https://5173-99eb0b994a1f14ee.monkeycode-ai.live"
  };
  if (!Array.isArray(data.kycRequests)) data.kycRequests = [];
  if (!Array.isArray(data.deposits)) data.deposits = [];
  (data.users || []).forEach((u) => {
    if (!u.kyc) u.kyc = null;
    if (!u.kycStatus) u.kycStatus = "pending";
    if (u.kyc && u.kyc.country === "EG") u.kyc.country = "SY";
  });
  bindOwnerAdmin(data);
  (data.ads || []).forEach((ad) => {
    ad.paymentTypes = ["SHAM_CASH"];
    if (ad.fiat === "EGP" || ad.fiat === "SAR" || ad.fiat === "AED") {
      if (ad.asset === "USDT") ad.price = ad.fiat === "EGP" ? Math.round(ad.price * 300) : 14750;
      ad.fiat = "SYP";
    }
    if (ad.asset !== "USDT") {
      ad.asset = "USDT";
      ad.fiat = ad.fiat === "USD" ? "USD" : "SYP";
    }
  });
  (data.paymentMethods || []).forEach((m) => {
    m.type = "SHAM_CASH";
    if (!m.details) m.details = {};
    if (!m.details.phone) m.details.phone = "0933000000";
    m.label = m.label && m.label.includes("شام") ? m.label : "شام كاش";
  });
  return data;
}

function load() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    db = seedDb();
    save();
    return;
  }
  try {
    db = migrate(JSON.parse(fs.readFileSync(DB_PATH, "utf8")));
    save();
  } catch {
    db = seedDb();
    save();
  }
}

function save() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

load();

function publicKyc(kyc) {
  if (!kyc) return null;
  return {
    fullName: kyc.fullName || "",
    nationalId: kyc.nationalId || "",
    country: kyc.country || "",
    documentType: kyc.documentType || "id",
    phone: kyc.phone || "",
    address: kyc.address || "",
    submittedAt: kyc.submittedAt || null,
    reviewedAt: kyc.reviewedAt || null,
    note: kyc.note || "",
    files: ((kyc.files || []).map((f) => ({
      id: f.id,
      kind: f.kind,
      name: f.name,
      mime: f.mime,
      size: f.size
    }))),
    level: kyc.level || "basic"
  };
}

function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    displayName: u.displayName,
    telegramId: u.telegramId || null,
    telegramUsername: u.telegramUsername || null,
    isMerchant: !!u.isMerchant,
    merchantStatus: u.merchantStatus || (u.isMerchant ? "approved" : "none"),
    isAdmin: !!u.isAdmin,
    kycStatus: u.kycStatus,
    kycLevel: u.kycLevel || (u.kycStatus === "verified" ? "basic" : "none"),
    kyc: publicKyc(u.kyc),
    rating: u.rating,
    completedTrades: u.completedTrades,
    createdAt: u.createdAt
  };
}

function getWallet(userId, asset) {
  let w = db.wallets.find((x) => x.userId === userId && x.asset === asset);
  if (!w) {
    w = { userId, asset, available: 0, frozen: 0 };
    db.wallets.push(w);
  }
  return w;
}

function freeze(userId, asset, amount) {
  const w = getWallet(userId, asset);
  if (w.available < amount - 1e-10) return false;
  w.available = round(w.available - amount, 8);
  w.frozen = round(w.frozen + amount, 8);
  return true;
}

function unfreeze(userId, asset, amount) {
  const w = getWallet(userId, asset);
  const a = Math.min(w.frozen, amount);
  w.frozen = round(w.frozen - a, 8);
  w.available = round(w.available + a, 8);
}

function releaseFrozenTo(fromId, toId, asset, amount) {
  const from = getWallet(fromId, asset);
  const to = getWallet(toId, asset);
  if (from.frozen < amount - 1e-10) return false;
  from.frozen = round(from.frozen - amount, 8);
  to.available = round(to.available + amount, 8);
  return true;
}

function credit(userId, asset, amount) {
  const w = getWallet(userId, asset);
  w.available = round(w.available + amount, 8);
}

function debit(userId, asset, amount) {
  const w = getWallet(userId, asset);
  if (w.available < amount - 1e-10) return false;
  w.available = round(w.available - amount, 8);
  return true;
}

function round(n, d) {
  const p = 10 ** d;
  return Math.round((n + Number.EPSILON) * p) / p;
}

function notify(userId, title, body, extra) {
  db.notifications.unshift({
    id: uid("n"),
    userId,
    title,
    body,
    extra: extra || {},
    read: false,
    createdAt: now()
  });
}

function getAssets(all) {
  return (db.assets || []).filter((a) => all || a.enabled);
}

function getFiats(all) {
  return (db.fiats || []).filter((f) => all || f.enabled);
}

function getPaymentTypes(all) {
  return (db.paymentTypes || []).filter((p) => all || p.enabled);
}

function ownerTelegramId() {
  return String((db.settings && db.settings.ownerTelegramId) || "1441524960");
}

function ensureUserFromTelegram(from) {
  const src = from || {};
  const tid = String(src.id);
  if (!tid || tid === "undefined") return null;
  if (tid === ownerTelegramId()) {
    const admin = db.users.find((u) => u.username === "admin") || db.users.find((u) => u.isAdmin);
    if (admin) {
      const extra = db.users.find((u) => u.id !== admin.id && String(u.telegramId) === tid);
      admin.telegramId = tid;
      admin.telegramUsername = src.username || admin.telegramUsername || null;
      admin.isAdmin = true;
      admin.isMerchant = true;
      admin.kycStatus = "verified";
      if (src.first_name) admin.displayName = [src.first_name, src.last_name].filter(Boolean).join(" ");
      if (extra) extra.telegramId = null;
      save();
      return admin;
    }
  }
  let user = db.users.find((u) => String(u.telegramId) === tid);
  if (user) return user;
  const uname = `tg_${tid}`;
  const p = hashPassword(`${tid}:${Date.now()}:${Math.random()}`);
  user = {
    id: uid("u"),
    username: uname,
    email: `${uname}@telegram.p2p`,
    displayName: [src.first_name, src.last_name].filter(Boolean).join(" ") || uname,
    passwordHash: p.hash,
    passwordSalt: p.salt,
    telegramId: tid,
    telegramUsername: src.username || null,
    isMerchant: false,
    merchantStatus: "none",
    isAdmin: false,
    kycStatus: "pending",
    kycLevel: "none",
    kyc: null,
    rating: 100,
    completedTrades: 0,
    createdAt: now()
  };
  db.users.push(user);
  getAssets(true).forEach((asset) => {
    db.wallets.push({
      userId: user.id,
      asset: asset.symbol,
      available: 0,
      frozen: 0
    });
  });
  notify(user.id, "حساب تلغرام", "تم إنشاء حسابك تلقائياً من بوت USDT شام.");
  save();
  return user;
}

function requireKyc(user, kind) {
  const s = db.settings || defaultSettings();
  const need =
    (kind === "trade" && s.requireKycForTrade) ||
    (kind === "ad" && s.requireKycForAd) ||
    (kind === "deposit" && s.requireKycForDeposit);
  if (!need) return null;
  if (!user || user.kycStatus !== "verified") {
    return "يجب إكمال توثيق الهوية KYC أولاً";
  }
  return null;
}

function requireMerchant(user) {
  const s = db.settings || defaultSettings();
  if (s.requireMerchantForAd === false) return null;
  if (!user) return "يجب تسجيل الدخول";
  if (user.isAdmin) return null;
  if (user.isMerchant || user.merchantStatus === "approved") return null;
  if (user.merchantStatus === "pending") return "طلب التاجر قيد موافقة المدير";
  return "يجب أن يوافق المدير على حسابك كتاجر قبل نشر الإعلانات";
}

function requireAdvancedKyc(user, amountUsdt) {
  const limit = Number((db.settings && db.settings.advancedKycUsdt) || 2000);
  if (!(Number(amountUsdt) > limit)) return null;
  if (!user || user.kycLevel !== "advanced") {
    return `التداول فوق ${limit} USDT يتطلب توثيقاً متقدماً مع إثبات السكن`;
  }
  return null;
}

module.exports = {
  db,
  save,
  load,
  uid,
  now,
  hashPassword,
  verifyPassword,
  publicUser,
  publicKyc,
  getWallet,
  freeze,
  unfreeze,
  releaseFrozenTo,
  credit,
  debit,
  notify,
  getAssets,
  getFiats,
  getPaymentTypes,
  requireKyc,
  requireMerchant,
  requireAdvancedKyc,
  ownerTelegramId,
  ensureUserFromTelegram,
  bindOwnerAdmin,
  defaultSettings,
  seedDb
};
