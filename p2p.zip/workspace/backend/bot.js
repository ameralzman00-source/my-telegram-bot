const TelegramBot = require("node-telegram-bot-api");
const {
  db,
  save,
  uid,
  now,
  hashPassword,
  freeze,
  unfreeze,
  releaseFrozenTo,
  credit,
  notify,
  getAssets,
  requireKyc,
  ownerTelegramId,
  ensureUserFromTelegram
} = require("./db");
const kycStore = require("./kycStore");

const TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const API = process.env.PUBLIC_API || "http://localhost:3001";
const pending = new Map();

function webAppUrl() {
  return String((db.settings && db.settings.webAppUrl) || process.env.WEB_APP_URL || "https://5173-99eb0b994a1f14ee.monkeycode-ai.live").replace(/\/$/, "");
}

function webAppButton(text) {
  return { text, web_app: { url: webAppUrl() } };
}

function isAdminUser(user) {
  return !!(user && (user.isAdmin || String(user.telegramId) === ownerTelegramId()));
}

function userFromMsg(msg) {
  return ensureUserFromTelegram(msg.from);
}

function cryptoRandom() {
  return Math.random().toString(36).slice(2) + Date.now();
}

function walletsOf(userId) {
  return db.wallets.filter((w) => w.userId === userId);
}

function fmt(n, d = 2) {
  return Number(n).toLocaleString("en-US", { maximumFractionDigits: d });
}

function mainKeyboard(user) {
  const rows = [
    [webAppButton("فتح المنصة")],
    [{ text: "شراء USDT" }, { text: "بيع USDT" }],
    [{ text: "محفظتي" }, { text: "صفقاتي" }],
    [{ text: "إعلاناتي" }, { text: "المساعدة" }]
  ];
  if (isAdminUser(user)) rows.push([{ text: "لوحة الإدارة" }]);
  return { keyboard: rows, resize_keyboard: true };
}

function adsKeyboard(ads, prefix) {
  const rows = ads.slice(0, 8).map((a) => {
    const owner = db.users.find((u) => u.id === a.userId);
    const name = owner ? owner.displayName : a.userId;
    return [
      {
        text: `${a.price} ${a.fiat} | ${fmt(a.minAmount)}-${fmt(a.maxAmount)} ${a.asset} | ${name}`,
        callback_data: `${prefix}:${a.id}`
      }
    ];
  });
  return { inline_keyboard: rows };
}

if (!TOKEN) {
  console.log("TELEGRAM_BOT_TOKEN غير معيّن. البوت لن يتصل بتيليجرام، والـ API يعمل بشكل مستقل.");
  console.log("ضع التوكن في backend/.env.example ثم شغّل: TELEGRAM_BOT_TOKEN=xxx node bot.js");
  setInterval(() => {}, 60 * 60 * 1000);
} else {
  const bot = new TelegramBot(TOKEN, { polling: true });

  bot.setChatMenuButton({
    menu_button: { type: "web_app", text: "المنصة", web_app: { url: webAppUrl() } }
  }).catch(() => {});

  bot.onText(/\/start(?:\s+(\S+))?/, (msg, match) => {
    const user = userFromMsg(msg);
    const payload = match && match[1];
    if (payload && payload.startsWith("LINK_")) {
      const code = payload.slice(5);
      const target = db.users.find(
        (u) => u.telegramLinkCode === code && u.telegramLinkExpires > now()
      );
      if (target) {
        target.telegramId = String(msg.from.id);
        target.telegramUsername = msg.from.username || null;
        target.telegramLinkCode = null;
        save();
        bot.sendMessage(msg.chat.id, `تم ربط حساب الموقع (${target.username}) بهذا التلغرام.`, { reply_markup: mainKeyboard(target) });
        return;
      }
    }
    const extra = isAdminUser(user)
      ? "\nأنت المدير. اضغط لوحة الإدارة للتحكم بالمنصة من البوت والموقع معاً."
      : "";
    bot.sendMessage(
      msg.chat.id,
      `أهلاً ${user.displayName}\nمنصة USDT شام لتداول التيثر في سوريا.\nشراء وبيع USDT مقابل الليرة السورية أو الدولار عبر شام كاش.${extra}\nاضغط فتح المنصة لدخول الموقع داخل تلغرام.`,
      { reply_markup: mainKeyboard(user) }
    );
    bot.sendMessage(msg.chat.id, "التطبيق المصغّر:", {
      reply_markup: { inline_keyboard: [[webAppButton("فتح المنصة")]] }
    });
  });

  bot.onText(/\/help|المساعدة/, (msg) => {
    bot.sendMessage(
      msg.chat.id,
      "USDT شام - سوريا\n1) اختر شراء أو بيع USDT\n2) اختر إعلاناً بالليرة أو الدولار\n3) أدخل الكمية\n4) ادفع عبر شام كاش ثم أكد\n5) البائع يفرج عن العملة\n\nحسابات تجريبية:\ndemo / demo123\nmerchant / merchant123\nbuyer / buyer123"
    );
  });

  bot.on("message", (msg) => {
    if (!msg.text || msg.text.startsWith("/")) return;
    const user = userFromMsg(msg);
    const text = msg.text.trim();
    const st = pending.get(user.id);

    if (st && st.step === "amount") {
      const qty = Number(text.replace(",", "."));
      const ad = db.ads.find((a) => a.id === st.adId && a.status === "active");
      pending.delete(user.id);
      if (!ad) return bot.sendMessage(msg.chat.id, "الإعلان لم يعد متاحاً.");
      if (!(qty >= ad.minAmount) || qty > ad.maxAmount) {
        return bot.sendMessage(msg.chat.id, `الكمية يجب أن تكون بين ${ad.minAmount} و ${ad.maxAmount}`);
      }
      const pay = ad.paymentTypes[0];
      try {
        const order = createOrder(user, ad, qty, pay);
        bot.sendMessage(
          msg.chat.id,
          formatOrder(order),
          {
            reply_markup: {
              inline_keyboard: [
                [{ text: "أكدت الدفع", callback_data: `paid:${order.id}` }],
                [{ text: "إلغاء", callback_data: `cancel:${order.id}` }],
                [{ text: "تفاصيل الصفقة", callback_data: `ord:${order.id}` }]
              ]
            }
          }
        );
      } catch (e) {
        bot.sendMessage(msg.chat.id, e.message || "تعذر إنشاء الصفقة");
      }
      return;
    }

    if (text === "شراء USDT") return sendAds(msg.chat.id, "SELL", "USDT");
    if (text === "بيع USDT") return sendAds(msg.chat.id, "BUY", "USDT");
    if (text === "محفظتي") {
      const lines = walletsOf(user.id).map((w) => `${w.asset}: متاح ${fmt(w.available, 6)} | مجمّد ${fmt(w.frozen, 6)}`);
      return bot.sendMessage(msg.chat.id, "محفظتك\n" + lines.join("\n"));
    }
    if (text === "صفقاتي") {
      const orders = db.orders.filter((o) => o.buyerId === user.id || o.sellerId === user.id).slice(0, 8);
      if (!orders.length) return bot.sendMessage(msg.chat.id, "لا توجد صفقات بعد.");
      const rows = orders.map((o) => [
        { text: `${statusAr(o.status)} ${o.amount} ${o.asset}`, callback_data: `ord:${o.id}` }
      ]);
      return bot.sendMessage(msg.chat.id, "آخر صفقاتك:", { reply_markup: { inline_keyboard: rows } });
    }
    if (text === "إعلاناتي") {
      const ads = db.ads.filter((a) => a.userId === user.id);
      if (!ads.length) return bot.sendMessage(msg.chat.id, "ليس لديك إعلانات. أنشئها من الموقع.");
      const lines = ads.map((a) => `${a.side} ${a.asset}/${a.fiat} @ ${a.price} | ${a.status}`);
      return bot.sendMessage(msg.chat.id, lines.join("\n"));
    }
    if (text === "فتح المنصة") {
      return bot.sendMessage(msg.chat.id, "افتح الموقع داخل تلغرام:", {
        reply_markup: { inline_keyboard: [[webAppButton("فتح المنصة")]] }
      });
    }
    if (text === "لوحة الإدارة") {
      if (!isAdminUser(user)) return bot.sendMessage(msg.chat.id, "هذه اللوحة للمدير فقط.");
      return sendAdminPanel(msg.chat.id);
    }
  });

  bot.on("callback_query", async (q) => {
    const msg = q.message;
    const user = ensureUserFromTelegram(q.from);
    const [action, id, extra] = (q.data || "").split(":");

    if (action === "buyad" || action === "sellad") {
      const ad = db.ads.find((a) => a.id === id);
      if (!ad) return bot.answerCallbackQuery(q.id, { text: "غير موجود" });
      pending.set(user.id, { step: "amount", adId: ad.id });
      bot.answerCallbackQuery(q.id);
      bot.sendMessage(
        msg.chat.id,
        `إعلان ${ad.side === "SELL" ? "بيع" : "شراء"} ${ad.asset}\nالسعر: ${ad.price} ${ad.fiat}\nالحد: ${ad.minAmount} - ${ad.maxAmount}\nالدفع: ${ad.paymentTypes.join(", ")}\nالشروط: ${ad.terms}\n\nأرسل الكمية الآن (${ad.asset})`
      );
      return;
    }

    if (action === "ord") {
      const order = db.orders.find((o) => o.id === id);
      if (!order) return bot.answerCallbackQuery(q.id, { text: "غير موجودة" });
      bot.answerCallbackQuery(q.id);
      const buttons = [];
      if (order.status === "pending_payment" && order.buyerId === user.id) {
        buttons.push([{ text: "أكدت الدفع", callback_data: `paid:${order.id}` }]);
      }
      if (order.status === "paid" && order.sellerId === user.id) {
        buttons.push([{ text: "إفراج عن العملة", callback_data: `release:${order.id}` }]);
      }
      if (["pending_payment", "paid"].includes(order.status)) {
        buttons.push([{ text: "فتح نزاع", callback_data: `dispute:${order.id}` }]);
        buttons.push([{ text: "إلغاء", callback_data: `cancel:${order.id}` }]);
      }
      bot.sendMessage(msg.chat.id, formatOrder(order), {
        reply_markup: { inline_keyboard: buttons }
      });
      return;
    }

    if (action === "paid") {
      const order = db.orders.find((o) => o.id === id);
      if (!order || order.buyerId !== user.id) return bot.answerCallbackQuery(q.id, { text: "غير مسموح" });
      if (order.status !== "pending_payment") return bot.answerCallbackQuery(q.id, { text: "حالة غير صالحة" });
      order.status = "paid";
      order.paidAt = now();
      notify(order.sellerId, "تم الدفع", `صفقة ${order.id}`, { orderId: order.id });
      save();
      pingSellerTelegram(bot, order);
      bot.answerCallbackQuery(q.id, { text: "تم تسجيل الدفع" });
      bot.sendMessage(msg.chat.id, "تم إشعار البائع. انتظر الإفراج.");
      return;
    }

    if (action === "release") {
      const order = db.orders.find((o) => o.id === id);
      if (!order || order.sellerId !== user.id) return bot.answerCallbackQuery(q.id, { text: "غير مسموح" });
      if (!["paid", "disputed"].includes(order.status)) {
        return bot.answerCallbackQuery(q.id, { text: "حالة غير صالحة" });
      }
      if (!releaseFrozenTo(order.sellerId, order.buyerId, order.asset, order.amount)) {
        return bot.answerCallbackQuery(q.id, { text: "فشل الإفراج" });
      }
      order.status = "completed";
      order.releasedAt = now();
      [order.buyerId, order.sellerId].forEach((uidx) => {
        const u = db.users.find((x) => x.id === uidx);
        if (u) u.completedTrades += 1;
      });
      save();
      bot.answerCallbackQuery(q.id, { text: "تم الإفراج" });
      bot.sendMessage(msg.chat.id, `أُفرج عن ${order.amount} ${order.asset} للمشتري.`);
      return;
    }

    if (action === "cancel") {
      const order = db.orders.find((o) => o.id === id);
      if (!order) return bot.answerCallbackQuery(q.id, { text: "غير موجودة" });
      if (order.buyerId !== user.id && order.sellerId !== user.id) {
        return bot.answerCallbackQuery(q.id, { text: "غير مسموح" });
      }
      if (order.status !== "pending_payment") return bot.answerCallbackQuery(q.id, { text: "لا يمكن الإلغاء" });
      const ad = db.ads.find((a) => a.id === order.adId);
      if (ad) {
        ad.available = Math.round((ad.available + order.amount) * 1e8) / 1e8;
        if (ad.status === "filled") ad.status = "active";
      }
      if (ad && ad.side === "BUY") unfreeze(order.sellerId, order.asset, order.amount);
      order.status = "cancelled";
      order.cancelledAt = now();
      save();
      bot.answerCallbackQuery(q.id, { text: "أُلغيت" });
      bot.sendMessage(msg.chat.id, "أُلغيت الصفقة.");
      return;
    }

    if (action === "dispute") {
      const order = db.orders.find((o) => o.id === id);
      if (!order) return bot.answerCallbackQuery(q.id, { text: "غير موجودة" });
      order.status = "disputed";
      order.disputeReason = "نزاع عبر تلغرام";
      save();
      bot.answerCallbackQuery(q.id, { text: "تم فتح النزاع" });
      bot.sendMessage(msg.chat.id, "تم فتح نزاع وستراجعه الإدارة من لوحة الموقع.");
      return;
    }

    if (action === "admin" || action.startsWith("adm")) {
      if (!isAdminUser(user)) return bot.answerCallbackQuery(q.id, { text: "للإدارة فقط" });
    }

    if (action === "admin") {
      bot.answerCallbackQuery(q.id);
      return sendAdminPanel(msg.chat.id);
    }

    if (action === "admkyc") {
      bot.answerCallbackQuery(q.id);
      const pendingKyc = db.users.filter((u) => u.kycStatus === "submitted").slice(0, 8);
      if (!pendingKyc.length) return bot.sendMessage(msg.chat.id, "لا توجد طلبات KYC معلّقة.");
      const rows = pendingKyc.map((u) => [
        { text: `عرض ملف ${u.username}`, callback_data: `kycview:${u.id}` }
      ]);
      return bot.sendMessage(msg.chat.id, "افتح الملف الكامل قبل القبول أو الرفض:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "kycview") {
      const target = db.users.find((u) => u.id === id);
      if (!target || !target.kyc) return bot.answerCallbackQuery(q.id, { text: "لا يوجد ملف" });
      bot.answerCallbackQuery(q.id);
      const k = target.kyc;
      const files = k.files || [];
      await bot.sendMessage(
        msg.chat.id,
        `ملف توثيق ${target.username}\nالاسم: ${k.fullName || "—"}\nالهوية: ${k.nationalId || "—"}\nالوثيقة: ${kycStore.docLabel(k.documentType)}\nالدولة: ${k.country || "—"}\nالهاتف: ${k.phone || "—"}\nالعنوان: ${k.address || "—"}\nالملفات: ${files.length}\nاطلع على الصور أدناه ثم قرر. للطباعة استخدم لوحة الموقع.`
      );
      for (const f of files) {
        try {
          const caption = `${kycStore.kindLabel(f.kind)} — ${f.name}`;
          if (kycStore.isImage(f)) {
            await bot.sendPhoto(msg.chat.id, kycStore.fileAbsPath(target.id, f), { caption });
          } else {
            await bot.sendDocument(msg.chat.id, kycStore.fileAbsPath(target.id, f), { caption });
          }
        } catch {
          await bot.sendMessage(msg.chat.id, `تعذر إرسال ${kycStore.kindLabel(f.kind)}`);
        }
      }
      if (!kycStore.hasRequiredFiles(k)) {
        return bot.sendMessage(msg.chat.id, "الملف ناقص. لا يمكن القبول حتى تكتمل الصور.");
      }
      return bot.sendMessage(msg.chat.id, "بعد الاطلاع:", {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "قبول بعد الاطلاع", callback_data: `kycok:${target.id}` },
              { text: "رفض", callback_data: `kycno:${target.id}` }
            ]
          ]
        }
      });
    }

    if (action === "kycok" || action === "kycno") {
      const target = db.users.find((u) => u.id === id);
      if (!target) return bot.answerCallbackQuery(q.id, { text: "غير موجود" });
      if (action === "kycok" && !kycStore.hasRequiredFiles(target.kyc)) {
        return bot.answerCallbackQuery(q.id, { text: "الملف ناقص", show_alert: true });
      }
      target.kycStatus = action === "kycok" ? "verified" : "rejected";
      if (!target.kyc) target.kyc = {};
      target.kyc.reviewedAt = now();
      target.kyc.reviewedBy = user.id;
      const reqRow = db.kycRequests.find((k) => k.userId === target.id && k.status === "submitted");
      if (reqRow) reqRow.status = target.kycStatus;
      notify(target.id, action === "kycok" ? "تم قبول KYC" : "رُفض توثيق KYC", "");
      save();
      bot.answerCallbackQuery(q.id, { text: "تم" });
      return bot.sendMessage(msg.chat.id, `KYC لـ ${target.username}: ${target.kycStatus === "verified" ? "مقبول بعد الاطلاع على الملف" : "مرفوض"}`);
    }

    if (action === "admdep") {
      bot.answerCallbackQuery(q.id);
      const pendingDeps = db.deposits.filter((d) => d.status === "pending").slice(0, 8);
      if (!pendingDeps.length) return bot.sendMessage(msg.chat.id, "لا توجد إيداعات معلّقة.");
      const rows = pendingDeps.map((d) => [
        { text: `قبول ${d.amount} ${d.asset}`, callback_data: `depok:${d.id}` },
        { text: "رفض", callback_data: `depno:${d.id}` }
      ]);
      return bot.sendMessage(msg.chat.id, "إيداعات BEP20:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "depok" || action === "depno") {
      const deposit = db.deposits.find((d) => d.id === id);
      if (!deposit || deposit.status !== "pending") return bot.answerCallbackQuery(q.id, { text: "غير صالح" });
      deposit.reviewedAt = now();
      deposit.reviewedBy = user.id;
      if (action === "depok") {
        credit(deposit.userId, deposit.asset, deposit.amount);
        deposit.status = "credited";
      } else {
        deposit.status = "rejected";
      }
      save();
      bot.answerCallbackQuery(q.id, { text: "تم" });
      return bot.sendMessage(msg.chat.id, action === "depok" ? "تم إضافة الرصيد." : "رُفض الإيداع.");
    }

    if (action === "admord") {
      bot.answerCallbackQuery(q.id);
      const open = db.orders.filter((o) => ["pending_payment", "paid", "disputed"].includes(o.status)).slice(0, 8);
      if (!open.length) return bot.sendMessage(msg.chat.id, "لا صفقات مفتوحة.");
      const rows = open.map((o) => [{ text: `${statusAr(o.status)} ${o.amount} ${o.asset}`, callback_data: `ord:${o.id}` }]);
      return bot.sendMessage(msg.chat.id, "الصفقات المفتوحة:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "admpay") {
      bot.answerCallbackQuery(q.id);
      const rows = db.paymentTypes.map((p) => [
        { text: `${p.enabled ? "إيقاف" : "تفعيل"} ${p.name}`, callback_data: `paytog:${p.id}` }
      ]);
      return bot.sendMessage(msg.chat.id, "طرق الدفع:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "paytog") {
      const item = db.paymentTypes.find((p) => p.id === id);
      if (!item) return bot.answerCallbackQuery(q.id, { text: "غير موجودة" });
      item.enabled = !item.enabled;
      save();
      bot.answerCallbackQuery(q.id, { text: item.enabled ? "مفعّلة" : "متوقفة" });
      return sendAdminPanel(msg.chat.id);
    }

    if (action === "admcoin") {
      bot.answerCallbackQuery(q.id);
      const rows = db.assets.map((a) => [
        { text: `${a.enabled ? "إيقاف" : "تفعيل"} ${a.symbol}`, callback_data: `cointog:${a.symbol}` }
      ]);
      return bot.sendMessage(msg.chat.id, "عملات المنصة:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "cointog") {
      const asset = db.assets.find((a) => a.symbol === id);
      if (!asset) return bot.answerCallbackQuery(q.id, { text: "غير موجودة" });
      asset.enabled = !asset.enabled;
      save();
      bot.answerCallbackQuery(q.id, { text: asset.enabled ? "مفعّلة" : "متوقفة" });
      return sendAdminPanel(msg.chat.id);
    }

    if (action === "admads") {
      bot.answerCallbackQuery(q.id);
      const pendingAds = db.ads.filter((a) => a.status === "pending").slice(0, 8);
      if (!pendingAds.length) return bot.sendMessage(msg.chat.id, "لا توجد إعلانات بانتظار الموافقة.");
      const rows = pendingAds.map((a) => {
        const owner = db.users.find((u) => u.id === a.userId);
        return [{ text: `${owner?.username || "?"} ${a.side} ${a.amount || a.available} ${a.asset}/${a.fiat}`, callback_data: `adview:${a.id}` }];
      });
      return bot.sendMessage(msg.chat.id, "إعلانات بانتظار الموافقة:", { reply_markup: { inline_keyboard: rows } });
    }

    if (action === "adview") {
      const ad = db.ads.find((a) => a.id === id);
      if (!ad) return bot.answerCallbackQuery(q.id, { text: "غير موجود" });
      bot.answerCallbackQuery(q.id);
      const owner = db.users.find((u) => u.id === ad.userId);
      return bot.sendMessage(
        msg.chat.id,
        `إعلان ${owner?.username || ad.userId}\n${ad.side === "SELL" ? "بيع" : "شراء"} ${ad.asset}/${ad.fiat}\nالسعر: ${ad.price}\nالحد: ${ad.minAmount}-${ad.maxAmount}\nالمتاح: ${ad.available}\nالدفع: ${(ad.paymentTypes || []).join(", ")}\nالشروط: ${ad.terms || "—"}\nالحالة: ${ad.status}`,
        {
          reply_markup: {
            inline_keyboard: ad.status === "pending"
              ? [[{ text: "قبول الإعلان", callback_data: `adok:${ad.id}` }, { text: "رفض", callback_data: `adno:${ad.id}` }]]
              : []
          }
        }
      );
    }

    if (action === "adok" || action === "adno") {
      const ad = db.ads.find((a) => a.id === id);
      if (!ad || ad.status !== "pending") return bot.answerCallbackQuery(q.id, { text: "غير صالح" });
      ad.reviewedAt = now();
      ad.reviewedBy = user.id;
      if (action === "adok") {
        ad.status = "active";
        notify(ad.userId, "تمت الموافقة على الإعلان", "إعلانك ظاهر الآن في السوق.");
      } else {
        if (ad.side === "SELL" && ad.available > 0) unfreeze(ad.userId, ad.asset, ad.available);
        ad.status = "rejected";
        ad.reviewNote = "رُفض من البوت";
        notify(ad.userId, "رُفض الإعلان", "لم تتم الموافقة على الإعلان.");
      }
      save();
      bot.answerCallbackQuery(q.id, { text: "تم" });
      return bot.sendMessage(msg.chat.id, action === "adok" ? "ظهر الإعلان في السوق." : "رُفض الإعلان.");
    }
  });

  function sendAdminPanel(chatId) {
    const pendingKyc = db.users.filter((u) => u.kycStatus === "submitted").length;
    const pendingDeps = db.deposits.filter((d) => d.status === "pending").length;
    const pendingAds = db.ads.filter((a) => a.status === "pending").length;
    const disputed = db.orders.filter((o) => o.status === "disputed").length;
    bot.sendMessage(
      chatId,
      `لوحة إدارة USDT شام\nالمستخدمون: ${db.users.length}\nKYC معلّق: ${pendingKyc}\nإيداعات معلّقة: ${pendingDeps}\nإعلانات معلّقة: ${pendingAds}\nنزاعات: ${disputed}\nالموقع والبوت على نفس البيانات.`,
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "طلبات KYC", callback_data: "admkyc" }, { text: "الإيداعات", callback_data: "admdep" }],
            [{ text: "إعلانات للقبول", callback_data: "admads" }, { text: "الصفقات", callback_data: "admord" }],
            [{ text: "طرق الدفع", callback_data: "admpay" }, { text: "العملات", callback_data: "admcoin" }]
          ]
        }
      }
    );
  }

  function sendAds(chatId, side, asset) {
    const ads = db.ads.filter((a) => a.status === "active" && a.side === side && a.asset === asset).slice(0, 8);
    if (!ads.length) return bot.sendMessage(chatId, "لا توجد إعلانات حالياً.");
    const prefix = side === "SELL" ? "buyad" : "sellad";
    const title = side === "SELL" ? "إعلانات البيع (أنت تشتري)" : "إعلانات الشراء (أنت تبيع)";
    bot.sendMessage(chatId, title, { reply_markup: adsKeyboard(ads, prefix) });
  }

  function pingSellerTelegram(bot, order) {
    const seller = db.users.find((u) => u.id === order.sellerId);
    if (seller && seller.telegramId) {
      bot.sendMessage(
        seller.telegramId,
        `المشتري أكد الدفع في صفقة ${order.id}\n${order.amount} ${order.asset} مقابل ${order.fiatAmount} ${order.fiat}`,
        {
          reply_markup: {
            inline_keyboard: [[{ text: "إفراج", callback_data: `release:${order.id}` }]]
          }
        }
      ).catch(() => {});
    }
  }

  console.log("USDT Sham Telegram bot polling...");
}

function createOrder(user, ad, qty, paymentType) {
  const kycErr = requireKyc(user, "trade");
  if (kycErr) throw new Error(kycErr);
  if (ad.userId === user.id) throw new Error("لا يمكنك التداول مع إعلانك");
  if (qty > ad.available) throw new Error("الكمية المتاحة غير كافية");
  let buyerId;
  let sellerId;
  if (ad.side === "SELL") {
    buyerId = user.id;
    sellerId = ad.userId;
  } else {
    buyerId = ad.userId;
    sellerId = user.id;
    if (!freeze(sellerId, ad.asset, qty)) throw new Error("رصيدك غير كافٍ");
  }
  ad.available = Math.round((ad.available - qty) * 1e8) / 1e8;
  if (ad.available <= 0) ad.status = "filled";
  const fiatAmount = Math.round(qty * ad.price * 100) / 100;
  const sellerMethods = db.paymentMethods.filter(
    (m) => m.userId === sellerId && m.active && m.type === paymentType
  );
  const order = {
    id: uid("ord"),
    adId: ad.id,
    buyerId,
    sellerId,
    takerId: user.id,
    makerId: ad.userId,
    side: ad.side,
    asset: ad.asset,
    fiat: ad.fiat,
    price: ad.price,
    amount: qty,
    fiatAmount,
    paymentType,
    paymentDetails: sellerMethods[0] ? sellerMethods[0].details : {},
    paymentLabel: sellerMethods[0] ? sellerMethods[0].label : paymentType,
    status: "pending_payment",
    createdAt: now(),
    expiresAt: now() + ad.timeLimitMin * 60 * 1000,
    paidAt: null,
    releasedAt: null,
    cancelledAt: null,
    disputeReason: null
  };
  db.orders.unshift(order);
  save();
  return order;
}

function formatOrder(order) {
  const details = JSON.stringify(order.paymentDetails || {}, null, 0);
  return [
    `صفقة ${order.id}`,
    `الحالة: ${statusAr(order.status)}`,
    `${order.amount} ${order.asset} @ ${order.price} ${order.fiat}`,
    `الإجمالي: ${order.fiatAmount} ${order.fiat}`,
    `الدفع: ${order.paymentLabel} (${order.paymentType})`,
    `بيانات التحويل: ${details}`
  ].join("\n");
}

function statusAr(s) {
  return (
    {
      pending_payment: "بانتظار الدفع",
      paid: "مدفوعة",
      completed: "مكتملة",
      cancelled: "ملغاة",
      disputed: "نزاع"
    }[s] || s
  );
}

module.exports = { createOrder };
