const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const path = require("path");
const {
  db,
  save,
  uid,
  now,
  hashPassword,
  verifyPassword,
  publicUser,
  publicKyc,
  getWallet,
  freeze,
  unfreeze,
  releaseFrozenTo,
  credit,
  debit,
  notify,
  getAssets,
  getFiats,
  getPaymentTypes,
  requireKyc,
  ensureUserFromTelegram
} = require("./db");
const kycStore = require("./kycStore");

const app = express();
const PORT = process.env.PORT || 3001;
const TOKEN_TTL = 7 * 24 * 60 * 60 * 1000;

app.use(cors());
app.use(express.json({ limit: "25mb" }));

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : req.query.token;
  if (!token) return res.status(401).json({ error: "يجب تسجيل الدخول" });
  const session = db.sessions.find((s) => s.token === token && s.expiresAt > now());
  if (!session) return res.status(401).json({ error: "جلسة غير صالحة" });
  const user = db.users.find((u) => u.id === session.userId);
  if (!user) return res.status(401).json({ error: "المستخدم غير موجود" });
  req.user = user;
  req.token = token;
  next();
}

function optionalAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (token) {
    const session = db.sessions.find((s) => s.token === token && s.expiresAt > now());
    if (session) req.user = db.users.find((u) => u.id === session.userId) || null;
  }
  next();
}

function createSession(userId) {
  const token = crypto.randomBytes(24).toString("hex");
  db.sessions.push({
    token,
    userId,
    createdAt: now(),
    expiresAt: now() + TOKEN_TTL
  });
  save();
  return token;
}

function enrichAd(ad) {
  const owner = db.users.find((u) => u.id === ad.userId);
  return {
    ...ad,
    owner: publicUser(owner)
  };
}

function enrichOrder(order) {
  const ad = db.ads.find((a) => a.id === order.adId);
  const buyer = db.users.find((u) => u.id === order.buyerId);
  const seller = db.users.find((u) => u.id === order.sellerId);
  return {
    ...order,
    ad: ad ? { id: ad.id, terms: ad.terms, timeLimitMin: ad.timeLimitMin } : null,
    buyer: publicUser(buyer),
    seller: publicUser(seller)
  };
}

function counterparty(order, userId) {
  return order.buyerId === userId ? order.sellerId : order.buyerId;
}

function adminOnly(req, res, next) {
  if (!req.user.isAdmin) return res.status(403).json({ error: "للإدارة فقط" });
  next();
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));
}

function isValidTxHash(h) {
  return /^0x[a-fA-F0-9]{64}$/.test(String(h || "").trim());
}

function isValidAddress(a) {
  return /^0x[a-fA-F0-9]{40}$/.test(String(a || "").trim());
}

function slugId(value, fallback) {
  const s = String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_]/g, "_")
    .slice(0, 24);
  return s || fallback;
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, name: "USDT شام", time: now() });
});

app.get("/api/meta", (req, res) => {
  res.json({
    assets: getAssets(),
    fiats: getFiats(),
    paymentTypes: getPaymentTypes(),
    settings: {
      brand: db.settings.brand || "USDT شام",
      country: db.settings.country || "SY",
      telegramBotUsername: db.settings.telegramBotUsername || "EntrepreneurMA_bot",
      webAppUrl: db.settings.webAppUrl || "https://5173-99eb0b994a1f14ee.monkeycode-ai.live",
      bep20Address: db.settings.bep20Address,
      bep20Network: db.settings.bep20Network,
      minDeposit: db.settings.minDeposit,
      requireKycForTrade: !!db.settings.requireKycForTrade,
      requireKycForAd: !!db.settings.requireKycForAd,
      requireKycForDeposit: !!db.settings.requireKycForDeposit
    }
  });
});

app.post("/api/auth/register", (req, res) => {
  const { username, email, password, displayName } = req.body || {};
  if (!username || !email || !password) {
    return res.status(400).json({ error: "اسم المستخدم والبريد وكلمة المرور مطلوبة" });
  }
  if (String(password).length < 6) {
    return res.status(400).json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" });
  }
  const uname = String(username).trim().toLowerCase();
  const mail = String(email).trim().toLowerCase();
  if (db.users.find((u) => u.username === uname)) {
    return res.status(400).json({ error: "اسم المستخدم مستخدم مسبقاً" });
  }
  if (db.users.find((u) => u.email === mail)) {
    return res.status(400).json({ error: "البريد مستخدم مسبقاً" });
  }
  const p = hashPassword(password);
  const user = {
    id: uid("u"),
    username: uname,
    email: mail,
    displayName: displayName || uname,
    passwordHash: p.hash,
    passwordSalt: p.salt,
    telegramId: null,
    telegramUsername: null,
    isMerchant: false,
    isAdmin: false,
    kycStatus: "pending",
    kyc: null,
    rating: 100,
    completedTrades: 0,
    createdAt: now()
  };
  db.users.push(user);
  getAssets(true).forEach((asset) => {
    db.wallets.push({
      userId: user.id,
      asset: asset.symbol,
      available: 0,
      frozen: 0
    });
  });
  const token = createSession(user.id);
  notify(user.id, "مرحباً بك في USDT شام", "تم إنشاء حسابك. أكمل توثيق KYC ثم أودع عبر BEP20 لبدء التداول.");
  save();
  res.json({ token, user: publicUser(user) });
});

app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "بيانات ناقصة" });
  const key = String(username).trim().toLowerCase();
  const user = db.users.find((u) => u.username === key || u.email === key);
  if (!user || !verifyPassword(password, user.passwordSalt, user.passwordHash)) {
    return res.status(401).json({ error: "بيانات الدخول غير صحيحة" });
  }
  const token = createSession(user.id);
  res.json({ token, user: publicUser(user) });
});

function verifyTelegramInitData(initData, botToken) {
  const params = new URLSearchParams(String(initData || ""));
  const hash = params.get("hash");
  if (!hash || !botToken) return null;
  params.delete("hash");
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const check = crypto.createHmac("sha256", secret).update(dataCheckString).digest("hex");
  if (check !== hash) return null;
  try {
    return JSON.parse(params.get("user") || "null");
  } catch {
    return null;
  }
}

app.post("/api/auth/telegram", (req, res) => {
  const botToken = process.env.TELEGRAM_BOT_TOKEN || "";
  const tgUser = verifyTelegramInitData(req.body && req.body.initData, botToken);
  if (!tgUser || !tgUser.id) return res.status(401).json({ error: "جلسة تلغرام غير صالحة" });
  const user = ensureUserFromTelegram(tgUser);
  if (!user) return res.status(401).json({ error: "تعذر إنشاء الحساب من تلغرام" });
  const token = createSession(user.id);
  res.json({ token, user: publicUser(user) });
});

app.post("/api/auth/logout", auth, (req, res) => {
  db.sessions = db.sessions.filter((s) => s.token !== req.token);
  save();
  res.json({ ok: true });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.put("/api/me", auth, (req, res) => {
  const { displayName } = req.body || {};
  if (displayName) req.user.displayName = String(displayName).slice(0, 40);
  save();
  res.json({ user: publicUser(req.user) });
});

app.get("/api/wallet", auth, (req, res) => {
  const enabled = getAssets(true).map((a) => a.symbol);
  enabled.forEach((symbol) => getWallet(req.user.id, symbol));
  const wallets = db.wallets.filter((w) => w.userId === req.user.id && enabled.includes(w.asset));
  res.json({ wallets });
});

app.get("/api/deposits", auth, (req, res) => {
  const items = db.deposits.filter((d) => d.userId === req.user.id);
  res.json({ deposits: items });
});

app.post("/api/deposits", auth, (req, res) => {
  const kycErr = requireKyc(req.user, "deposit");
  if (kycErr) return res.status(403).json({ error: kycErr });
  const { asset, amount, txHash, fromAddress } = req.body || {};
  const coin = getAssets().find((x) => x.symbol === asset && x.depositEnabled);
  if (!coin) return res.status(400).json({ error: "عملة الإيداع غير مدعومة على BEP20" });
  const a = Number(amount);
  if (!(a > 0) || a > 1e7) return res.status(400).json({ error: "مبلغ غير صالح" });
  if (a < Number(db.settings.minDeposit || 0)) {
    return res.status(400).json({ error: `الحد الأدنى للإيداع ${db.settings.minDeposit} ${asset}` });
  }
  if (!isValidTxHash(txHash)) return res.status(400).json({ error: "هاش المعاملة غير صالح (BEP20 0x... 64)" });
  const hash = String(txHash).trim();
  if (db.deposits.find((d) => d.txHash.toLowerCase() === hash.toLowerCase())) {
    return res.status(400).json({ error: "هذا الهاش مستخدم مسبقاً" });
  }
  if (fromAddress && !isValidAddress(fromAddress)) {
    return res.status(400).json({ error: "عنوان المحفظة المرسلة غير صالح" });
  }
  const deposit = {
    id: uid("dep"),
    userId: req.user.id,
    asset: coin.symbol,
    network: "BEP20",
    amount: a,
    txHash: hash,
    fromAddress: fromAddress ? String(fromAddress).trim() : "",
    toAddress: db.settings.bep20Address,
    status: "pending",
    note: "",
    createdAt: now(),
    reviewedAt: null,
    reviewedBy: null
  };
  db.deposits.unshift(deposit);
  notify(req.user.id, "طلب إيداع BEP20", `بانتظار مراجعة الإدارة: ${a} ${asset}`);
  db.users.filter((u) => u.isAdmin).forEach((u) => {
    notify(u.id, "إيداع جديد", `${req.user.username} أرسل ${a} ${asset}`, { depositId: deposit.id });
  });
  save();
  res.json({ deposit });
});

app.get("/api/payment-methods", auth, (req, res) => {
  res.json({ methods: db.paymentMethods.filter((m) => m.userId === req.user.id) });
});

app.post("/api/payment-methods", auth, (req, res) => {
  const { type, label, details } = req.body || {};
  if (!getPaymentTypes().find((p) => p.id === type) || !label) {
    return res.status(400).json({ error: "طريقة دفع غير صالحة" });
  }
  const method = {
    id: uid("pm"),
    userId: req.user.id,
    type,
    label: String(label).slice(0, 60),
    details: details || {},
    active: true
  };
  db.paymentMethods.push(method);
  save();
  res.json({ method });
});

app.delete("/api/payment-methods/:id", auth, (req, res) => {
  const i = db.paymentMethods.findIndex((m) => m.id === req.params.id && m.userId === req.user.id);
  if (i < 0) return res.status(404).json({ error: "غير موجودة" });
  db.paymentMethods[i].active = false;
  save();
  res.json({ ok: true });
});

app.get("/api/ads", optionalAuth, (req, res) => {
  const { side, asset, fiat, payment, q, minRating } = req.query;
  let ads = db.ads.filter((a) => a.status === "active");
  if (side) ads = ads.filter((a) => a.side === String(side).toUpperCase());
  if (asset) ads = ads.filter((a) => a.asset === String(asset).toUpperCase());
  if (fiat) ads = ads.filter((a) => a.fiat === String(fiat).toUpperCase());
  if (payment) ads = ads.filter((a) => a.paymentTypes.includes(String(payment).toUpperCase()));
  if (minRating) {
    ads = ads.filter((a) => {
      const u = db.users.find((x) => x.id === a.userId);
      return u && u.rating >= Number(minRating);
    });
  }
  if (q) {
    const s = String(q).toLowerCase();
    ads = ads.filter((a) => {
      const u = db.users.find((x) => x.id === a.userId);
      return (
        (u && (u.username.includes(s) || (u.displayName || "").toLowerCase().includes(s))) ||
        a.asset.toLowerCase().includes(s) ||
        a.fiat.toLowerCase().includes(s)
      );
    });
  }
  ads.sort((a, b) => {
    if (a.side === "SELL") return a.price - b.price;
    return b.price - a.price;
  });
  res.json({ ads: ads.map(enrichAd) });
});

app.get("/api/ads/mine", auth, (req, res) => {
  res.json({ ads: db.ads.filter((a) => a.userId === req.user.id).map(enrichAd) });
});

app.get("/api/ads/:id", (req, res) => {
  const ad = db.ads.find((a) => a.id === req.params.id);
  if (!ad) return res.status(404).json({ error: "الإعلان غير موجود" });
  res.json({ ad: enrichAd(ad) });
});

app.post("/api/ads", auth, (req, res) => {
  const kycErr = requireKyc(req.user, "ad");
  if (kycErr) return res.status(403).json({ error: kycErr });
  const { side, asset, fiat, price, minAmount, maxAmount, available, paymentTypes, terms, timeLimitMin } = req.body || {};
  if (!["BUY", "SELL"].includes(side)) return res.status(400).json({ error: "نوع الإعلان غير صالح" });
  if (!getAssets().find((x) => x.symbol === asset)) return res.status(400).json({ error: "أصل غير مدعوم" });
  if (!getFiats().find((x) => x.code === fiat)) return res.status(400).json({ error: "عملة فيات غير مدعومة" });
  const p = Number(price);
  const minA = Number(minAmount);
  const maxA = Number(maxAmount);
  const avail = Number(available);
  if (!(p > 0) || !(minA > 0) || !(maxA >= minA) || !(avail >= maxA)) {
    return res.status(400).json({ error: "حدود المبالغ أو السعر غير صالحة" });
  }
  const pts = Array.isArray(paymentTypes) ? paymentTypes : [];
  if (!pts.length || pts.some((t) => !getPaymentTypes().find((x) => x.id === t))) {
    return res.status(400).json({ error: "اختر طريقة دفع واحدة على الأقل" });
  }
  if (side === "SELL") {
    if (!freeze(req.user.id, asset, avail)) {
      return res.status(400).json({ error: "رصيد غير كافٍ لتغطية الإعلان" });
    }
  }
  const ad = {
    id: uid("ad"),
    userId: req.user.id,
    side,
    asset,
    fiat,
    price: p,
    minAmount: minA,
    maxAmount: maxA,
    available: avail,
    paymentTypes: pts,
    terms: String(terms || "").slice(0, 500),
    timeLimitMin: Math.min(Math.max(Number(timeLimitMin) || 15, 5), 120),
    status: req.user.isAdmin ? "active" : "pending",
    reviewNote: "",
    reviewedAt: null,
    reviewedBy: null,
    createdAt: now()
  };
  db.ads.unshift(ad);
  db.users.filter((u) => u.isAdmin).forEach((u) => {
    notify(u.id, "إعلان بانتظار الموافقة", `${req.user.username} أرسل إعلان ${ad.side} ${ad.asset}/${ad.fiat}`);
  });
  notify(req.user.id, "تم إرسال الإعلان", req.user.isAdmin ? "إعلانك ظاهر في السوق." : "إعلانك قيد مراجعة المدير ولن يظهر في السوق قبل الموافقة.");
  save();
  res.json({ ad: enrichAd(ad) });
});

app.post("/api/ads/:id/toggle", auth, (req, res) => {
  const ad = db.ads.find((a) => a.id === req.params.id && a.userId === req.user.id);
  if (!ad) return res.status(404).json({ error: "الإعلان غير موجود" });
  if (ad.status === "pending" || ad.status === "rejected") {
    return res.status(400).json({ error: "الإعلان بانتظار موافقة المدير ولا يمكن تشغيله" });
  }
  if (ad.status === "active") {
    if (ad.side === "SELL" && ad.available > 0) unfreeze(req.user.id, ad.asset, ad.available);
    ad.status = "paused";
  } else if (ad.status === "paused") {
    if (ad.side === "SELL") {
      if (!freeze(req.user.id, ad.asset, ad.available)) {
        return res.status(400).json({ error: "رصيد غير كافٍ لإعادة تفعيل الإعلان" });
      }
    }
    ad.status = "active";
  }
  save();
  res.json({ ad: enrichAd(ad) });
});

app.post("/api/orders", auth, (req, res) => {
  const kycErr = requireKyc(req.user, "trade");
  if (kycErr) return res.status(403).json({ error: kycErr });
  const { adId, amount, paymentType } = req.body || {};
  const ad = db.ads.find((a) => a.id === adId && a.status === "active");
  if (!ad) return res.status(404).json({ error: "الإعلان غير متاح" });
  if (ad.userId === req.user.id) return res.status(400).json({ error: "لا يمكنك التداول مع إعلانك" });
  const qty = Number(amount);
  if (!(qty >= ad.minAmount) || qty > ad.maxAmount + 1e-12) {
    return res.status(400).json({ error: `المبلغ يجب أن يكون بين ${ad.minAmount} و ${ad.maxAmount}` });
  }
  if (qty > ad.available + 1e-12) return res.status(400).json({ error: "الكمية المتاحة غير كافية" });
  if (!ad.paymentTypes.includes(paymentType)) {
    return res.status(400).json({ error: "طريقة الدفع غير مدعومة في هذا الإعلان" });
  }

  let buyerId;
  let sellerId;
  if (ad.side === "SELL") {
    buyerId = req.user.id;
    sellerId = ad.userId;
  } else {
    buyerId = ad.userId;
    sellerId = req.user.id;
    if (!freeze(sellerId, ad.asset, qty)) {
      return res.status(400).json({ error: "رصيدك غير كافٍ لبيع هذه الكمية" });
    }
  }

  ad.available = Math.round((ad.available - qty) * 1e8) / 1e8;
  if (ad.available <= 0) ad.status = "filled";

  const fiatAmount = Math.round(qty * ad.price * 100) / 100;
  const sellerMethods = db.paymentMethods.filter(
    (m) => m.userId === sellerId && m.active && m.type === paymentType
  );
  const order = {
    id: uid("ord"),
    adId: ad.id,
    buyerId,
    sellerId,
    takerId: req.user.id,
    makerId: ad.userId,
    side: ad.side,
    asset: ad.asset,
    fiat: ad.fiat,
    price: ad.price,
    amount: qty,
    fiatAmount,
    paymentType,
    paymentDetails: sellerMethods[0] ? sellerMethods[0].details : {},
    paymentLabel: sellerMethods[0] ? sellerMethods[0].label : paymentType,
    status: "pending_payment",
    createdAt: now(),
    expiresAt: now() + ad.timeLimitMin * 60 * 1000,
    paidAt: null,
    releasedAt: null,
    cancelledAt: null,
    disputeReason: null
  };
  db.orders.unshift(order);
  db.messages.push({
    id: uid("msg"),
    orderId: order.id,
    userId: "system",
    text: `تم إنشاء الصفقة. المشتري يحول ${fiatAmount} ${ad.fiat} خلال ${ad.timeLimitMin} دقيقة.`,
    createdAt: now()
  });
  notify(buyerId, "صفقة جديدة", `اشتريت ${qty} ${ad.asset} مقابل ${fiatAmount} ${ad.fiat}`, { orderId: order.id });
  notify(sellerId, "صفقة جديدة", `بيع ${qty} ${ad.asset} مقابل ${fiatAmount} ${ad.fiat}`, { orderId: order.id });
  save();
  res.json({ order: enrichOrder(order) });
});

app.get("/api/orders", auth, (req, res) => {
  const { status } = req.query;
  let orders = db.orders.filter((o) => o.buyerId === req.user.id || o.sellerId === req.user.id);
  if (status === "open") {
    orders = orders.filter((o) => ["pending_payment", "paid", "disputed"].includes(o.status));
  } else if (status) {
    orders = orders.filter((o) => o.status === status);
  }
  res.json({ orders: orders.map(enrichOrder) });
});

app.get("/api/orders/:id", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "الصفقة غير موجودة" });
  if (order.buyerId !== req.user.id && order.sellerId !== req.user.id && !req.user.isAdmin) {
    return res.status(403).json({ error: "غير مصرح" });
  }
  const messages = db.messages.filter((m) => m.orderId === order.id);
  res.json({ order: enrichOrder(order), messages });
});

app.post("/api/orders/:id/paid", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "غير موجودة" });
  if (order.buyerId !== req.user.id) return res.status(403).json({ error: "المشتري فقط يؤكد الدفع" });
  if (order.status !== "pending_payment") return res.status(400).json({ error: "لا يمكن تأكيد الدفع في هذه الحالة" });
  if (now() > order.expiresAt) {
    expireOrder(order);
    save();
    return res.status(400).json({ error: "انتهى وقت الدفع وألغيت الصفقة" });
  }
  order.status = "paid";
  order.paidAt = now();
  db.messages.push({
    id: uid("msg"),
    orderId: order.id,
    userId: "system",
    text: "أكد المشتري أنه دفع. يرجى من البائع التحقق ثم الإفراج عن العملة.",
    createdAt: now()
  });
  notify(order.sellerId, "تم الدفع", `المشتري أكد دفع صفقة ${order.id}`, { orderId: order.id });
  save();
  res.json({ order: enrichOrder(order) });
});

app.post("/api/orders/:id/release", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "غير موجودة" });
  if (order.sellerId !== req.user.id && !req.user.isAdmin) {
    return res.status(403).json({ error: "البائع فقط يفرج عن العملة" });
  }
  if (!["paid", "disputed"].includes(order.status)) {
    return res.status(400).json({ error: "لا يمكن الإفراج في هذه الحالة" });
  }
  if (!releaseFrozenTo(order.sellerId, order.buyerId, order.asset, order.amount)) {
    return res.status(400).json({ error: "فشل الإفراج عن الرصيد المجمّد" });
  }
  order.status = "completed";
  order.releasedAt = now();
  completeTradeStats(order);
  db.messages.push({
    id: uid("msg"),
    orderId: order.id,
    userId: "system",
    text: `تم الإفراج عن ${order.amount} ${order.asset} إلى محفظة المشتري. الصفقة مكتملة.`,
    createdAt: now()
  });
  notify(order.buyerId, "تم الإفراج", `استلمت ${order.amount} ${order.asset}`, { orderId: order.id });
  notify(order.sellerId, "صفقة مكتملة", `أتممت بيع ${order.amount} ${order.asset}`, { orderId: order.id });
  save();
  res.json({ order: enrichOrder(order) });
});

app.post("/api/orders/:id/cancel", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "غير موجودة" });
  const isParty = order.buyerId === req.user.id || order.sellerId === req.user.id;
  if (!isParty && !req.user.isAdmin) return res.status(403).json({ error: "غير مصرح" });
  if (!["pending_payment", "disputed"].includes(order.status) && !req.user.isAdmin) {
    return res.status(400).json({ error: "لا يمكن الإلغاء بعد تأكيد الدفع إلا عبر النزاع/الإدارة" });
  }
  cancelOrder(order, req.user.id);
  save();
  res.json({ order: enrichOrder(order) });
});

app.post("/api/orders/:id/dispute", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "غير موجودة" });
  if (order.buyerId !== req.user.id && order.sellerId !== req.user.id) {
    return res.status(403).json({ error: "غير مصرح" });
  }
  if (!["pending_payment", "paid"].includes(order.status)) {
    return res.status(400).json({ error: "لا يمكن فتح نزاع في هذه الحالة" });
  }
  order.status = "disputed";
  order.disputeReason = String((req.body && req.body.reason) || "نزاع").slice(0, 400);
  db.messages.push({
    id: uid("msg"),
    orderId: order.id,
    userId: "system",
    text: `تم فتح نزاع: ${order.disputeReason}`,
    createdAt: now()
  });
  notify(counterparty(order, req.user.id), "نزاع", `تم فتح نزاع على صفقة ${order.id}`, { orderId: order.id });
  const admins = db.users.filter((u) => u.isAdmin);
  admins.forEach((a) => notify(a.id, "نزاع جديد", `صفقة ${order.id}`, { orderId: order.id }));
  save();
  res.json({ order: enrichOrder(order) });
});

app.post("/api/orders/:id/messages", auth, (req, res) => {
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "غير موجودة" });
  if (order.buyerId !== req.user.id && order.sellerId !== req.user.id && !req.user.isAdmin) {
    return res.status(403).json({ error: "غير مصرح" });
  }
  const text = String((req.body && req.body.text) || "").trim().slice(0, 1000);
  if (!text) return res.status(400).json({ error: "الرسالة فارغة" });
  const msg = {
    id: uid("msg"),
    orderId: order.id,
    userId: req.user.id,
    text,
    createdAt: now()
  };
  db.messages.push(msg);
  notify(counterparty(order, req.user.id), "رسالة جديدة", text.slice(0, 80), { orderId: order.id });
  save();
  res.json({ message: msg });
});

app.get("/api/notifications", auth, (req, res) => {
  const items = db.notifications.filter((n) => n.userId === req.user.id).slice(0, 50);
  res.json({ notifications: items });
});

app.post("/api/notifications/read", auth, (req, res) => {
  db.notifications.forEach((n) => {
    if (n.userId === req.user.id) n.read = true;
  });
  save();
  res.json({ ok: true });
});

app.get("/api/stats", (req, res) => {
  const completed = db.orders.filter((o) => o.status === "completed");
  const volume = completed.reduce((s, o) => s + (o.asset === "USDT" ? o.amount : o.fiatAmount / (o.price || 1)), 0);
  res.json({
    users: db.users.length,
    ads: db.ads.filter((a) => a.status === "active").length,
    orders: db.orders.length,
    completed: completed.length,
    volumeUsdt: Math.round(volume * 100) / 100
  });
});

app.get("/api/kyc", auth, (req, res) => {
  res.json({ status: req.user.kycStatus, kyc: publicKyc(req.user.kyc) });
});

app.post("/api/kyc", auth, (req, res) => {
  if (req.user.kycStatus === "verified") {
    return res.status(400).json({ error: "حسابك موثّق مسبقاً" });
  }
  const { fullName, nationalId, country, documentType, phone, address, files } = req.body || {};
  if (!fullName || !nationalId || !country) {
    return res.status(400).json({ error: "الاسم ورقم الهوية والدولة مطلوبة" });
  }
  if (!Array.isArray(files) || !files.length) {
    return res.status(400).json({ error: "ارفع صور الهوية والوجه قبل الإرسال" });
  }
  let savedFiles;
  try {
    savedFiles = kycStore.saveFiles(req.user.id, files);
  } catch (e) {
    return res.status(400).json({ error: e.message || "تعذر حفظ الملفات" });
  }
  const kyc = {
    fullName: String(fullName).slice(0, 80),
    nationalId: String(nationalId).slice(0, 40),
    country: String(country).slice(0, 40),
    documentType: String(documentType || "id").slice(0, 30),
    phone: String(phone || "").slice(0, 40),
    address: String(address || "").slice(0, 160),
    submittedAt: now(),
    reviewedAt: null,
    note: "",
    files: savedFiles
  };
  if (!kycStore.hasRequiredFiles(kyc)) {
    return res.status(400).json({ error: "مطلوب: وجه الهوية، ظهر الهوية، وصورة شخصية مع الوثيقة" });
  }
  req.user.kyc = kyc;
  req.user.kycStatus = "submitted";
  const existing = db.kycRequests.find((k) => k.userId === req.user.id && k.status === "submitted");
  if (!existing) {
    db.kycRequests.unshift({
      id: uid("kyc"),
      userId: req.user.id,
      status: "submitted",
      createdAt: now()
    });
  }
  db.users.filter((u) => u.isAdmin).forEach((u) => {
    notify(u.id, "طلب KYC", `${req.user.username} أرسل ملف توثيق كامل للمراجعة`);
  });
  notify(req.user.id, "تم إرسال KYC", "طلب التوثيق قيد المراجعة. لن يُقبل إلا بعد اطلاع المدير على الصور.");
  save();
  res.json({ user: publicUser(req.user) });
});

app.get("/api/admin/overview", auth, adminOnly, (req, res) => {
  res.json({
    users: db.users.length,
    ads: db.ads.length,
    orders: db.orders.length,
    pendingKyc: db.users.filter((u) => u.kycStatus === "submitted").length,
    pendingDeposits: db.deposits.filter((d) => d.status === "pending").length,
    pendingAds: db.ads.filter((a) => a.status === "pending").length,
    disputed: db.orders.filter((o) => o.status === "disputed").length
  });
});

app.get("/api/admin/users", auth, adminOnly, (req, res) => {
  res.json({ users: db.users.map(publicUser) });
});

app.post("/api/admin/users/:id", auth, adminOnly, (req, res) => {
  const user = db.users.find((u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  const { isMerchant, isAdmin, kycStatus } = req.body || {};
  if (typeof isMerchant === "boolean") user.isMerchant = isMerchant;
  if (typeof isAdmin === "boolean" && user.id !== req.user.id) user.isAdmin = isAdmin;
  if (kycStatus && ["pending", "submitted", "verified", "rejected"].includes(kycStatus)) {
    user.kycStatus = kycStatus;
  }
  save();
  res.json({ user: publicUser(user) });
});

function kycDossier(user) {
  const kyc = user.kyc || {};
  const files = kycStore.publicFiles(kyc).map((f) => ({
    ...f,
    url: `/api/admin/kyc/${user.id}/file/${f.id}`
  }));
  return {
    user: publicUser(user),
    status: user.kycStatus,
    kyc: {
      ...publicKyc(kyc),
      documentLabel: kycStore.docLabel(kyc.documentType),
      files
    },
    printUrl: `/api/admin/kyc/${user.id}/print`
  };
}

app.get("/api/admin/kyc", auth, adminOnly, (req, res) => {
  const items = db.users
    .filter((u) => u.kycStatus === "submitted" || (u.kyc && u.kyc.submittedAt))
    .map(kycDossier);
  res.json({ requests: items });
});

app.get("/api/admin/kyc/:userId", auth, adminOnly, (req, res) => {
  const user = db.users.find((u) => u.id === req.params.userId);
  if (!user || !user.kyc) return res.status(404).json({ error: "لا يوجد ملف توثيق" });
  res.json(kycDossier(user));
});

app.get("/api/admin/kyc/:userId/file/:fileId", auth, adminOnly, (req, res) => {
  const user = db.users.find((u) => u.id === req.params.userId);
  if (!user || !user.kyc) return res.status(404).json({ error: "لا يوجد ملف توثيق" });
  const file = kycStore.findFile(user.kyc, req.params.fileId);
  if (!file) return res.status(404).json({ error: "الملف غير موجود" });
  try {
    const buf = kycStore.readFile(user.id, file);
    res.setHeader("Content-Type", file.mime);
    res.setHeader("Content-Disposition", `inline; filename="${encodeURIComponent(file.name || file.storedName)}"`);
    res.setHeader("Cache-Control", "private, max-age=120");
    res.send(buf);
  } catch {
    res.status(404).json({ error: "تعذر قراءة الملف" });
  }
});

app.get("/api/admin/kyc/:userId/print", auth, adminOnly, (req, res) => {
  const user = db.users.find((u) => u.id === req.params.userId);
  if (!user || !user.kyc) return res.status(404).json({ error: "لا يوجد ملف توثيق" });
  const kyc = user.kyc;
  const statusMap = { submitted: "قيد المراجعة", verified: "موثّق", rejected: "مرفوض", pending: "غير مكتمل" };
  const when = (t) => (t ? new Date(t).toLocaleString("ar-SY") : "—");
  const images = (kyc.files || [])
    .filter((f) => kycStore.isImage(f))
    .map((f) => {
      let src = "";
      try {
        src = `data:${f.mime};base64,${kycStore.readFile(user.id, f).toString("base64")}`;
      } catch {
        return `<p>${escapeHtml(kycStore.kindLabel(f.kind))} — تعذر قراءة الملف</p>`;
      }
      return `<figure><img src="${src}" alt="${escapeHtml(kycStore.kindLabel(f.kind))}"><figcaption>${escapeHtml(kycStore.kindLabel(f.kind))} — ${escapeHtml(f.name)}</figcaption></figure>`;
    })
    .join("");
  const pdfs = (kyc.files || [])
    .filter((f) => !kycStore.isImage(f))
    .map((f) => `<li>${escapeHtml(kycStore.kindLabel(f.kind))}: ${escapeHtml(f.name)} (${Math.round(f.size / 1024)} KB)</li>`)
    .join("");
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>ملف توثيق — ${escapeHtml(user.username)}</title>
  <style>
    body{font-family:Tahoma,Arial,sans-serif;margin:24px;color:#111}
    h1{margin:0 0 8px}
    .meta{display:grid;grid-template-columns:1fr 1fr;gap:8px 24px;margin:16px 0 24px}
    .meta div{border-bottom:1px solid #ddd;padding:6px 0}
    .label{color:#555;font-size:12px}
    figure{margin:0 0 18px;page-break-inside:avoid}
    img{max-width:100%;border:1px solid #ccc}
    figcaption{font-size:13px;color:#444;margin-top:6px}
    .stamp{margin-top:28px;display:flex;justify-content:space-between}
    @media print {.noprint{display:none}}
  </style>
</head>
<body>
  <p class="noprint"><button onclick="window.print()">طباعة / حفظ PDF</button></p>
  <h1>USDT شام — ملف توثيق الهوية</h1>
  <p>نسخة إدارية رسمية للمراجعة والطباعة</p>
  <div class="meta">
    <div><div class="label">اسم المستخدم</div>${escapeHtml(user.username)}</div>
    <div><div class="label">الاسم الكامل</div>${escapeHtml(kyc.fullName || "—")}</div>
    <div><div class="label">رقم الهوية</div>${escapeHtml(kyc.nationalId || "—")}</div>
    <div><div class="label">نوع الوثيقة</div>${escapeHtml(kycStore.docLabel(kyc.documentType))}</div>
    <div><div class="label">الدولة</div>${escapeHtml(kyc.country || "—")}</div>
    <div><div class="label">الهاتف</div>${escapeHtml(kyc.phone || "—")}</div>
    <div><div class="label">العنوان</div>${escapeHtml(kyc.address || "—")}</div>
    <div><div class="label">البريد</div>${escapeHtml(user.email || "—")}</div>
    <div><div class="label">تلغرام</div>${escapeHtml(user.telegramId || "—")}</div>
    <div><div class="label">الحالة</div>${escapeHtml(statusMap[user.kycStatus] || user.kycStatus)}</div>
    <div><div class="label">تاريخ الإرسال</div>${escapeHtml(when(kyc.submittedAt))}</div>
    <div><div class="label">تاريخ المراجعة</div>${escapeHtml(when(kyc.reviewedAt))}</div>
  </div>
  ${images || "<p>لا توجد صور مرفقة.</p>"}
  ${pdfs ? `<h3>مستندات غير صورية</h3><ul>${pdfs}</ul>` : ""}
  ${kyc.note ? `<p>ملاحظة الإدارة: ${escapeHtml(kyc.note)}</p>` : ""}
  <div class="stamp">
    <div>توقيع المراجع: ____________</div>
    <div>ختم المنصة: ____________</div>
  </div>
</body>
</html>`);
});

app.post("/api/admin/kyc/:userId", auth, adminOnly, (req, res) => {
  const user = db.users.find((u) => u.id === req.params.userId);
  if (!user) return res.status(404).json({ error: "المستخدم غير موجود" });
  const { action, note } = req.body || {};
  if (!["approve", "reject"].includes(action)) return res.status(400).json({ error: "إجراء غير صالح" });
  if (action === "approve") {
    if (!user.kyc || !kycStore.hasRequiredFiles(user.kyc)) {
      return res.status(400).json({ error: "لا يمكن القبول بدون ملف توثيق كامل (وجه، ظهر، سيلفي)" });
    }
  }
  user.kycStatus = action === "approve" ? "verified" : "rejected";
  if (!user.kyc) user.kyc = {};
  user.kyc.reviewedAt = now();
  user.kyc.reviewedBy = req.user.id;
  user.kyc.note = String(note || "").slice(0, 300);
  const reqRow = db.kycRequests.find((k) => k.userId === user.id && k.status === "submitted");
  if (reqRow) reqRow.status = user.kycStatus;
  notify(user.id, action === "approve" ? "تم قبول KYC" : "رُفض توثيق KYC", note || "");
  save();
  res.json({ user: publicUser(user) });
});

app.get("/api/admin/deposits", auth, adminOnly, (req, res) => {
  const items = db.deposits.map((d) => ({
    ...d,
    user: publicUser(db.users.find((u) => u.id === d.userId))
  }));
  res.json({ deposits: items });
});

app.post("/api/admin/deposits/:id", auth, adminOnly, (req, res) => {
  const deposit = db.deposits.find((d) => d.id === req.params.id);
  if (!deposit) return res.status(404).json({ error: "الإيداع غير موجود" });
  if (deposit.status !== "pending") return res.status(400).json({ error: "تمت معالجة هذا الإيداع" });
  const { action, note } = req.body || {};
  deposit.note = String(note || "").slice(0, 300);
  deposit.reviewedAt = now();
  deposit.reviewedBy = req.user.id;
  if (action === "approve") {
    credit(deposit.userId, deposit.asset, deposit.amount);
    deposit.status = "credited";
    notify(deposit.userId, "تم قبول الإيداع", `أُضيف ${deposit.amount} ${deposit.asset} إلى محفظتك عبر BEP20`);
  } else if (action === "reject") {
    deposit.status = "rejected";
    notify(deposit.userId, "رُفض الإيداع", deposit.note || "لم يتم التحقق من التحويل على BEP20");
  } else {
    return res.status(400).json({ error: "إجراء غير صالح" });
  }
  save();
  res.json({ deposit });
});

app.get("/api/admin/orders", auth, adminOnly, (req, res) => {
  res.json({ orders: db.orders.map(enrichOrder) });
});

app.get("/api/admin/ads", auth, adminOnly, (req, res) => {
  res.json({ ads: db.ads.map(enrichAd) });
});

app.post("/api/admin/ads/:id/toggle", auth, adminOnly, (req, res) => {
  const ad = db.ads.find((a) => a.id === req.params.id);
  if (!ad) return res.status(404).json({ error: "الإعلان غير موجود" });
  if (ad.status === "pending" || ad.status === "rejected") {
    return res.status(400).json({ error: "راجع الإعلان بالموافقة أو الرفض أولاً" });
  }
  if (ad.status === "active") {
    if (ad.side === "SELL" && ad.available > 0) unfreeze(ad.userId, ad.asset, ad.available);
    ad.status = "paused";
  } else if (ad.status === "paused") {
    if (ad.side === "SELL" && !freeze(ad.userId, ad.asset, ad.available)) {
      return res.status(400).json({ error: "رصيد المعلن غير كافٍ" });
    }
    ad.status = "active";
  }
  save();
  res.json({ ad: enrichAd(ad) });
});

app.post("/api/admin/ads/:id/review", auth, adminOnly, (req, res) => {
  const ad = db.ads.find((a) => a.id === req.params.id);
  if (!ad) return res.status(404).json({ error: "الإعلان غير موجود" });
  const { action, note } = req.body || {};
  if (!["approve", "reject"].includes(action)) return res.status(400).json({ error: "إجراء غير صالح" });
  if (ad.status !== "pending") return res.status(400).json({ error: "هذا الإعلان ليس بانتظار المراجعة" });
  ad.reviewedAt = now();
  ad.reviewedBy = req.user.id;
  ad.reviewNote = String(note || "").slice(0, 300);
  if (action === "approve") {
    ad.status = "active";
    notify(ad.userId, "تمت الموافقة على الإعلان", "إعلانك ظاهر الآن في السوق.");
  } else {
    if (ad.side === "SELL" && ad.available > 0) unfreeze(ad.userId, ad.asset, ad.available);
    ad.status = "rejected";
    notify(ad.userId, "رُفض الإعلان", ad.reviewNote || "لم تتم الموافقة على الإعلان.");
  }
  save();
  res.json({ ad: enrichAd(ad) });
});

app.get("/api/admin/catalog", auth, adminOnly, (req, res) => {
  res.json({
    assets: db.assets,
    fiats: db.fiats,
    paymentTypes: db.paymentTypes,
    settings: db.settings
  });
});

app.post("/api/admin/settings", auth, adminOnly, (req, res) => {
  const body = req.body || {};
  if (body.bep20Address) {
    if (!isValidAddress(body.bep20Address)) return res.status(400).json({ error: "عنوان BEP20 غير صالح" });
    db.settings.bep20Address = String(body.bep20Address).trim();
  }
  if (body.telegramBotUsername) {
    db.settings.telegramBotUsername = String(body.telegramBotUsername).replace(/^@/, "").slice(0, 40);
  }
  if (body.webAppUrl) {
    const url = String(body.webAppUrl).trim().replace(/\/$/, "");
    if (!/^https:\/\//i.test(url)) return res.status(400).json({ error: "رابط التطبيق يجب أن يبدأ بـ https" });
    db.settings.webAppUrl = url.slice(0, 200);
  }
  if (body.bep20Network) db.settings.bep20Network = String(body.bep20Network).slice(0, 40);
  if (body.minDeposit != null) {
    const m = Number(body.minDeposit);
    if (!(m >= 0)) return res.status(400).json({ error: "حد الإيداع غير صالح" });
    db.settings.minDeposit = m;
  }
  ["requireKycForTrade", "requireKycForAd", "requireKycForDeposit"].forEach((k) => {
    if (typeof body[k] === "boolean") db.settings[k] = body[k];
  });
  save();
  res.json({ settings: db.settings });
});

app.post("/api/admin/assets", auth, adminOnly, (req, res) => {
  const { symbol, name, decimals, contract, depositEnabled } = req.body || {};
  const sym = slugId(symbol);
  if (!sym || !name) return res.status(400).json({ error: "رمز واسم العملة مطلوبان" });
  if (db.assets.find((a) => a.symbol === sym)) return res.status(400).json({ error: "العملة موجودة" });
  const asset = {
    symbol: sym,
    name: String(name).slice(0, 40),
    decimals: Math.min(Math.max(Number(decimals) || 2, 0), 18),
    network: "BEP20",
    contract: contract ? String(contract).trim() : "",
    enabled: true,
    depositEnabled: depositEnabled !== false
  };
  db.assets.push(asset);
  db.users.forEach((u) => getWallet(u.id, sym));
  save();
  res.json({ asset });
});

app.post("/api/admin/assets/:symbol", auth, adminOnly, (req, res) => {
  const asset = db.assets.find((a) => a.symbol === String(req.params.symbol).toUpperCase());
  if (!asset) return res.status(404).json({ error: "العملة غير موجودة" });
  const { name, decimals, contract, enabled, depositEnabled } = req.body || {};
  if (name) asset.name = String(name).slice(0, 40);
  if (decimals != null) asset.decimals = Math.min(Math.max(Number(decimals) || 0, 0), 18);
  if (contract != null) asset.contract = String(contract).trim();
  if (typeof enabled === "boolean") asset.enabled = enabled;
  if (typeof depositEnabled === "boolean") asset.depositEnabled = depositEnabled;
  save();
  res.json({ asset });
});

app.post("/api/admin/fiats", auth, adminOnly, (req, res) => {
  const { code, name, symbol } = req.body || {};
  const c = slugId(code).slice(0, 8);
  if (!c || !name) return res.status(400).json({ error: "رمز واسم العملة الورقية مطلوبان" });
  if (db.fiats.find((f) => f.code === c)) return res.status(400).json({ error: "العملة موجودة" });
  const fiat = { code: c, name: String(name).slice(0, 40), symbol: String(symbol || c).slice(0, 8), enabled: true };
  db.fiats.push(fiat);
  save();
  res.json({ fiat });
});

app.post("/api/admin/fiats/:code", auth, adminOnly, (req, res) => {
  const fiat = db.fiats.find((f) => f.code === String(req.params.code).toUpperCase());
  if (!fiat) return res.status(404).json({ error: "غير موجودة" });
  const { name, symbol, enabled } = req.body || {};
  if (name) fiat.name = String(name).slice(0, 40);
  if (symbol) fiat.symbol = String(symbol).slice(0, 8);
  if (typeof enabled === "boolean") fiat.enabled = enabled;
  save();
  res.json({ fiat });
});

app.post("/api/admin/payment-types", auth, adminOnly, (req, res) => {
  const { id, name, fields } = req.body || {};
  const pid = slugId(id || name);
  if (!pid || !name) return res.status(400).json({ error: "معرف واسم طريقة الدفع مطلوبان" });
  if (db.paymentTypes.find((p) => p.id === pid)) return res.status(400).json({ error: "طريقة الدفع موجودة" });
  const item = {
    id: pid,
    name: String(name).slice(0, 40),
    icon: "wallet",
    enabled: true,
    fields: String(fields || "account,name").slice(0, 80)
  };
  db.paymentTypes.push(item);
  save();
  res.json({ paymentType: item });
});

app.post("/api/admin/payment-types/:id", auth, adminOnly, (req, res) => {
  const item = db.paymentTypes.find((p) => p.id === String(req.params.id).toUpperCase());
  if (!item) return res.status(404).json({ error: "غير موجودة" });
  const { name, fields, enabled } = req.body || {};
  if (name) item.name = String(name).slice(0, 40);
  if (fields) item.fields = String(fields).slice(0, 80);
  if (typeof enabled === "boolean") item.enabled = enabled;
  save();
  res.json({ paymentType: item });
});

app.post("/api/telegram/link", auth, (req, res) => {
  const code = crypto.randomBytes(4).toString("hex").toUpperCase();
  req.user.telegramLinkCode = code;
  req.user.telegramLinkExpires = now() + 10 * 60 * 1000;
  save();
  res.json({ code, expiresIn: 600 });
});

function expireOrder(order) {
  if (order.status !== "pending_payment") return;
  cancelOrder(order, "system");
}

function cancelOrder(order, by) {
  if (["completed", "cancelled"].includes(order.status)) return;
  const ad = db.ads.find((a) => a.id === order.adId);
  if (ad) {
    ad.available = Math.round((ad.available + order.amount) * 1e8) / 1e8;
    if (ad.status === "filled") ad.status = "active";
  }
  if (ad && ad.side === "BUY") {
    unfreeze(order.sellerId, order.asset, order.amount);
  }
  order.status = "cancelled";
  order.cancelledAt = now();
  db.messages.push({
    id: uid("msg"),
    orderId: order.id,
    userId: "system",
    text: by === "system" ? "أُلغيت الصفقة لانتهاء المهلة." : "أُلغيت الصفقة.",
    createdAt: now()
  });
}

function completeTradeStats(order) {
  [order.buyerId, order.sellerId].forEach((id) => {
    const u = db.users.find((x) => x.id === id);
    if (u) u.completedTrades += 1;
  });
}

setInterval(() => {
  let changed = false;
  db.orders.forEach((o) => {
    if (o.status === "pending_payment" && now() > o.expiresAt) {
      expireOrder(o);
      changed = true;
    }
  });
  if (changed) save();
}, 15000);

app.listen(PORT, "0.0.0.0", () => {
  console.log(`USDT Sham API on ${PORT}`);
});

module.exports = { app };
